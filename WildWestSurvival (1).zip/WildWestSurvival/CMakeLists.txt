cmake_minimum_required(VERSION 3.16)
project(WildWestSurvival VERSION 0.2.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release CACHE STRING "Build type" FORCE)
endif()

# Под Emscripten получаем веб-версию (WebAssembly): тесты там запустить нельзя.
if(EMSCRIPTEN)
  set(_ws_default_tests OFF)
else()
  set(_ws_default_tests ON)
endif()

option(WS_BUILD_GAME  "Собирать игру (нужен raylib)" ON)
option(WS_BUILD_TESTS "Собирать тесты" ${_ws_default_tests})

if(MSVC)
  add_compile_options(/utf-8 /W4)
else()
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# --- Ядро симуляции: чистый C++, никакой графики ---------------------------
add_library(ws_sim STATIC
  src/sim/WorldClock.cpp
  src/sim/Survival.cpp
  src/sim/Terrain.cpp
  src/sim/Player.cpp
  src/sim/World.cpp)
target_include_directories(ws_sim PUBLIC src)

# --- Ввод без привязки к библиотеке окна (сенсорное управление) -------------
add_library(ws_input STATIC src/input/TouchControls.cpp)
target_include_directories(ws_input PUBLIC src)

if(WS_BUILD_TESTS)
  enable_testing()
  add_executable(ws_sim_tests tests/sim_tests.cpp)
  target_link_libraries(ws_sim_tests PRIVATE ws_sim)
  add_test(NAME sim COMMAND ws_sim_tests)

  add_executable(ws_input_tests tests/input_tests.cpp)
  target_link_libraries(ws_input_tests PRIVATE ws_input)
  add_test(NAME input COMMAND ws_input_tests)
endif()

# --- Игра: рендер и ввод на raylib -----------------------------------------
if(WS_BUILD_GAME)
  if(EMSCRIPTEN)
    set(PLATFORM Web CACHE STRING "raylib platform" FORCE)
  else()
    find_package(raylib 5.0 QUIET)
  endif()
  if(NOT raylib_FOUND)
    include(FetchContent)
    set(BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
    FetchContent_Declare(raylib
      GIT_REPOSITORY https://github.com/raysan5/raylib.git
      GIT_TAG        5.5
      GIT_SHALLOW    ON)
    FetchContent_MakeAvailable(raylib)
  endif()

  add_executable(wild_west
    src/app/main.cpp
    src/app/Game.cpp
    src/render/Renderer.cpp)
  target_link_libraries(wild_west PRIVATE ws_sim ws_input raylib)

  if(EMSCRIPTEN)
    # Результат лежит в build/web: index.html + index.js + index.wasm + index.data
    set_target_properties(wild_west PROPERTIES
      OUTPUT_NAME index
      SUFFIX ".html"
      RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/web")
    target_link_options(wild_west PRIVATE
      "-sALLOW_MEMORY_GROWTH=1"
      "-sSTACK_SIZE=1048576"
      "-sGL_ENABLE_GET_PROC_ADDRESS=1"
      "--shell-file=${CMAKE_SOURCE_DIR}/web/shell.html"
      "--preload-file=${CMAKE_SOURCE_DIR}/assets@/assets")
    set_property(TARGET wild_west APPEND PROPERTY LINK_DEPENDS "${CMAKE_SOURCE_DIR}/web/shell.html")
  else()
    # Шрифт и прочие ресурсы кладём рядом с исполняемым файлом.
    add_custom_command(TARGET wild_west POST_BUILD
      COMMAND ${CMAKE_COMMAND} -E copy_directory
              "${CMAKE_SOURCE_DIR}/assets" "$<TARGET_FILE_DIR:wild_west>/assets")
  endif()
endif()
