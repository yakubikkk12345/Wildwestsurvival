#include "app/Game.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

namespace ws {

namespace {

#ifdef __EMSCRIPTEN__
constexpr bool kWeb = true;
#else
constexpr bool kWeb = false;
#endif

constexpr int   kDefaultW = 1280;
constexpr int   kDefaultH = 720;
constexpr float kMouseSens = 0.0023f;
constexpr float kFov = 70.f;

#ifdef __EMSCRIPTEN__
void webFrame(void* arg) { static_cast<Game*>(arg)->frame(); }
#endif

} // namespace

Game::Game() {
    int w = kDefaultW, h = kDefaultH;
#ifdef __EMSCRIPTEN__
    // Окно браузера: рисуем на всю вкладку.
    w = emscripten_run_script_int("window.innerWidth");
    h = emscripten_run_script_int("window.innerHeight");
    if (w <= 0 || h <= 0) {
        w = kDefaultW;
        h = kDefaultH;
    }
#endif
    unsigned flags = FLAG_VSYNC_HINT | FLAG_WINDOW_RESIZABLE;
    if (!kWeb) flags |= FLAG_MSAA_4X_HINT;
    SetConfigFlags(flags);
    InitWindow(w, h, "Wild West Survival");
    SetExitKey(KEY_NULL);  // Esc — пауза, а не выход
    if (!kWeb) SetTargetFPS(144);
    loadFont();

    // В браузере (особенно на телефоне) мир облегчён: меньше объектов и ближе прорисовка.
    WorldConfig cfg;
    if (kWeb) {
        cfg.cactusCount = 170;
        cfg.rockCount = 90;
        cfg.deadTreeCount = 45;
    }
    world_ = std::make_unique<World>(cfg);
    renderer_ = std::make_unique<Renderer>(*world_);
    renderer_->setPropDrawDistance(kWeb ? 110.f : 200.f);

    if (kWeb) {
        // Захват мыши и запуск игры разрешены браузером только после клика/касания.
        state_ = State::Paused;
        started_ = false;
    } else {
        state_ = State::Playing;
        started_ = true;
        DisableCursor();
    }
}

Game::~Game() {
    renderer_.reset();
    if (customFont_) UnloadFont(font_);
    CloseWindow();
}

// Ищем шрифт с кириллицей. Если нет — интерфейс переключается на английский.
void Game::loadFont() {
    font_ = GetFontDefault();

    std::vector<int> cps;
    for (int c = 32; c <= 126; ++c) cps.push_back(c);
    for (int c = 0x410; c <= 0x44F; ++c) cps.push_back(c);  // А-я
    cps.push_back(0x401);                                   // Ё
    cps.push_back(0x451);                                   // ё
    cps.push_back(0x2014);                                  // —
    cps.push_back(0xB0);                                    // °

    std::vector<std::string> candidates = {
        "assets/font.ttf",
        "../assets/font.ttf",
        std::string(GetApplicationDirectory()) + "assets/font.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "C:/Windows/Fonts/arial.ttf",
    };
    for (const std::string& path : candidates) {
        if (!FileExists(path.c_str())) continue;
        Font f = LoadFontEx(path.c_str(), 32, cps.data(), static_cast<int>(cps.size()));
        if (f.texture.id != 0 && f.texture.id != GetFontDefault().texture.id) {
            SetTextureFilter(f.texture, TEXTURE_FILTER_BILINEAR);
            font_ = f;
            customFont_ = true;
            cyrillic_ = true;
            return;
        }
    }
}

void Game::text(const char* s, float x, float y, float size, Color c) const {
    DrawTextEx(font_, s, Vector2{x, y}, size, size * 0.05f, c);
}

float Game::textWidth(const char* s, float size) const {
    return MeasureTextEx(font_, s, size, size * 0.05f).x;
}

void Game::centered(const char* s, float y, float size, Color c) const {
    text(s, (static_cast<float>(GetScreenWidth()) - textWidth(s, size)) * 0.5f, y, size, c);
}

void Game::readTouches(std::vector<TouchPoint>& out) const {
    out.clear();
    const int n = GetTouchPointCount();
    for (int i = 0; i < n; ++i) {
        const Vector2 p = GetTouchPosition(i);
        out.push_back(TouchPoint{GetTouchPointId(i), p.x, p.y});
    }
}

// Переходы между "играем", "пауза / старт" и "погибли".
void Game::updateState(float dt, bool portrait) {
    const TouchOutput& tout = touch_.out();
    const bool mouseClick = !touchMode_ && IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
    const bool tap = touchMode_ && tout.tapped;

    auto goPlaying = [&]() {
        state_ = State::Playing;
        started_ = true;
        skipLook_ = 3;
        if (!touchMode_) {
            DisableCursor();
            lockSeen_ = false;
        }
    };
    auto goPaused = [&]() {
        state_ = State::Paused;
        if (!touchMode_) EnableCursor();
    };

    switch (state_) {
        case State::Playing:
            if (IsKeyPressed(KEY_ESCAPE) || (touchMode_ && tout.pause) || portrait) {
                goPaused();
            } else if (kWeb && !touchMode_) {
                // Браузер сам снимает захват мыши по Esc — тогда ставим паузу.
                if (IsCursorHidden()) lockSeen_ = true;
                else if (lockSeen_) {
                    lockSeen_ = false;
                    goPaused();
                }
            }
            break;
        case State::Paused:
            if (started_ && IsKeyPressed(KEY_ESCAPE) && !portrait) goPlaying();
            else if ((mouseClick || tap) && !portrait) goPlaying();
            else if (!kWeb && IsKeyPressed(KEY_Q)) quit_ = true;
            break;
        case State::Dead:
            deadTimer_ += dt;
            if (deadTimer_ > 0.8f && (IsKeyPressed(KEY_R) || tap)) {
                world_->respawn();
                goPlaying();
            }
            break;
    }
}

void Game::readPlayerInput(PlayerInput& in, bool& interact) {
    interact = false;
    moveIntent_ = sprintIntent_ = false;

    if (touchMode_) {
        const TouchOutput& t = touch_.out();
        in.moveForward = t.moveForward;
        in.moveRight = t.moveRight;
        in.lookYaw = t.lookYaw;
        in.lookPitch = t.lookPitch;
        in.sprint = t.sprint;
        in.jump = t.jump;
        interact = t.interact;
    } else {
        const Vector2 md = GetMouseDelta();
        in.lookYaw = md.x * kMouseSens;
        in.lookPitch = md.y * kMouseSens;
        in.moveForward = (IsKeyDown(KEY_W) ? 1.f : 0.f) - (IsKeyDown(KEY_S) ? 1.f : 0.f);
        in.moveRight = (IsKeyDown(KEY_D) ? 1.f : 0.f) - (IsKeyDown(KEY_A) ? 1.f : 0.f);
        in.sprint = IsKeyDown(KEY_LEFT_SHIFT);
        in.jump = IsKeyPressed(KEY_SPACE);
        interact = IsKeyPressed(KEY_E);
    }

    if (skipLook_ > 0) {  // после паузы курсор мог прыгнуть — не крутим камеру рывком
        --skipLook_;
        in.lookYaw = in.lookPitch = 0.f;
    }
    moveIntent_ = std::fabs(in.moveForward) + std::fabs(in.moveRight) > 0.1f;
    sprintIntent_ = in.sprint && world_->survival().canSprint();
}

Camera3D Game::makeCamera(float dt) {
    const Player& p = world_->player();
    Vec3 eye = p.eyePosition();

    // Лёгкое покачивание при ходьбе.
    const bool walking = state_ == State::Playing && p.grounded() && moveIntent_;
    if (walking) bobPhase_ += dt * (sprintIntent_ ? 12.f : 8.f);
    eye.y += walking ? std::sin(bobPhase_) * 0.035f : 0.f;

    // Не даём камере уйти под землю на склоне.
    const float ground = world_->terrain().heightAt(eye.x, eye.z);
    if (eye.y < ground + 0.4f) eye.y = ground + 0.4f;

    const Vec3 f = p.forward();
    Camera3D cam{};
    cam.position = Vector3{eye.x, eye.y, eye.z};
    cam.target = Vector3{eye.x + f.x, eye.y + f.y, eye.z + f.z};
    cam.up = Vector3{0.f, 1.f, 0.f};
    cam.fovy = kFov;
    cam.projection = CAMERA_PERSPECTIVE;
    return cam;
}

const char* Game::interactionText(Interaction::Kind k) const {
    using K = Interaction::Kind;
    const char* what = nullptr;
    switch (k) {
        case K::DrinkOasis:  what = tr("пить воду", "drink water"); break;
        case K::DrinkBarrel: what = tr("набрать воды из бочки", "drink from the barrel"); break;
        case K::Loot:        what = tr("обыскать ящик", "search the crate"); break;
        case K::Cactus:      what = tr("срезать кактус (вода)", "cut the cactus (water)"); break;
        case K::None:        return "";
    }
    static char buf[128];
    const char* prefix = touchMode_ ? tr("Действие: ", "Action: ") : tr("E — ", "E - ");
    std::snprintf(buf, sizeof buf, "%s%s", prefix, what);
    return buf;
}

void Game::drawBar(float x, float y, float w, float h, float value, Color fill, const char* label) {
    const float t = clampf(value / Survival::kMax, 0.f, 1.f);
    DrawRectangle(static_cast<int>(x), static_cast<int>(y), static_cast<int>(w), static_cast<int>(h), Color{0, 0, 0, 140});
    // Когда показатель на исходе, полоска мигает красным.
    Color c = fill;
    if (t < 0.2f && std::fmod(time_, 0.8f) < 0.4f) c = Color{220, 50, 40, 255};
    DrawRectangle(static_cast<int>(x) + 2, static_cast<int>(y) + 2, static_cast<int>((w - 4.f) * t),
                  static_cast<int>(h) - 4, c);
    DrawRectangleLines(static_cast<int>(x), static_cast<int>(y), static_cast<int>(w), static_cast<int>(h),
                       Color{255, 255, 255, 120});
    const float fs = h * 0.62f;
    text(label, x + 8.f, y + h * 0.5f - fs * 0.5f, fs, WHITE);
}

void Game::drawHud() {
    const int sw = GetScreenWidth(), sh = GetScreenHeight();
    const float fsw = static_cast<float>(sw), fsh = static_cast<float>(sh);
    const Survival& s = world_->survival();
    const WorldClock& clock = world_->clock();

    // Вспышка при уроне.
    if (hurtFlash_ > 0.f)
        DrawRectangle(0, 0, sw, sh, Color{200, 0, 0, static_cast<unsigned char>(clampf(hurtFlash_, 0.f, 1.f) * 110.f)});

    // Жажда и голод затемняют края экрана.
    const float danger = 1.f - clampf(std::min(s.water, s.food) / 25.f, 0.f, 1.f);
    if (danger > 0.f) {
        const unsigned char a = static_cast<unsigned char>(danger * 70.f);
        DrawRectangleGradientH(0, 0, sw / 6, sh, Color{0, 0, 0, a}, Color{0, 0, 0, 0});
        DrawRectangleGradientH(sw - sw / 6, 0, sw / 6, sh, Color{0, 0, 0, 0}, Color{0, 0, 0, a});
    }

    // Прицел.
    DrawRectangle(sw / 2 - 1, sh / 2 - 7, 2, 14, Color{255, 255, 255, 170});
    DrawRectangle(sw / 2 - 7, sh / 2 - 1, 14, 2, Color{255, 255, 255, 170});

    // Подсказка действия.
    const char* prompt = interactionText(world_->interaction().kind);
    if (prompt[0] != '\0') centered(prompt, fsh * 0.58f, u(24.f), Color{255, 240, 200, 255});

    // Полоски выживания: на компьютере слева внизу, на телефоне вверху (внизу пальцы).
    const char* names[4] = {tr("Здоровье", "Health"), tr("Вода", "Water"), tr("Еда", "Food"),
                            tr("Выносливость", "Stamina")};
    const float vals[4] = {s.health, s.water, s.food, s.stamina};
    const Color cols[4] = {Color{200, 60, 60, 255}, Color{70, 150, 220, 255}, Color{200, 150, 60, 255},
                           s.exhausted ? Color{160, 120, 40, 255} : Color{120, 190, 90, 255}};
    const float bh = touchMode_ ? u(22.f) : u(24.f);
    const float gap = u(6.f);
    const float bw = touchMode_ ? u(200.f) : u(240.f);
    float bx = u(24.f), by = fsh - u(24.f) - 4.f * (bh + gap);
    if (touchMode_) {
        const TouchLayout& L = touch_.layout();
        bx = L.pause.x + L.pause.r + u(14.f);
        by = u(12.f);
    }
    for (int i = 0; i < 4; ++i) {
        drawBar(bx, by, bw, bh, vals[i], cols[i], names[i]);
        by += bh + gap;
    }

    // Время и температура.
    char buf[160];
    const int hh = static_cast<int>(clock.hour());
    const int mm = static_cast<int>((clock.hour() - static_cast<float>(hh)) * 60.f);
    std::snprintf(buf, sizeof buf, "%s %d   %02d:%02d   %.0f%s", tr("День", "Day"), clock.day(), hh, mm,
                  clock.ambientTemperature(), tr("°C", " C"));
    text(buf, fsw - textWidth(buf, u(22.f)) - u(24.f), u(16.f), u(22.f), Color{255, 255, 255, 230});

    // Короткие сообщения.
    if (messageTimer_ > 0.f)
        centered(message_, fsh * 0.2f, u(26.f),
                 Color{255, 255, 255, static_cast<unsigned char>(clampf(messageTimer_, 0.f, 1.f) * 255.f)});

    // Подсказка по управлению в самом начале.
    if (time_ < 14.f && started_) {
        const char* hint = touchMode_
            ? tr("Слева — ходьба (до кольца — бег)   Справа — осмотр   Кнопки: прыжок и действие",
                 "Left: move (to the ring - sprint)   Right: look around   Buttons: jump and action")
            : tr("WASD — ходьба   Shift — бег   Пробел — прыжок   E — действие   Esc — пауза",
                 "WASD - move   Shift - sprint   Space - jump   E - interact   Esc - pause");
        centered(hint, fsh - u(touchMode_ ? 28.f : 40.f), u(18.f), Color{255, 255, 255, 200});
    }

    if (showDebug_) {
        const Vec3& p = world_->player().position();
        std::snprintf(buf, sizeof buf, "FPS %d  pos %.1f %.1f %.1f  props %zu  deaths %d", GetFPS(), p.x, p.y, p.z,
                      world_->props().size(), world_->deaths());
        text(buf, 12.f, fsh - 28.f, 16.f, Color{255, 255, 0, 255});
    }
}

void Game::drawTouchButton(const TouchCircle& c, bool held, bool highlight, const char* label) {
    const int cx = static_cast<int>(c.x), cy = static_cast<int>(c.y);
    Color fill = highlight ? Color{255, 220, 120, 95} : Color{255, 255, 255, 45};
    if (held) fill = Color{255, 255, 255, 140};
    DrawCircle(cx, cy, c.r, fill);
    DrawCircleLines(cx, cy, c.r, Color{255, 255, 255, 150});
    const float fs = c.r * 0.34f;
    text(label, c.x - textWidth(label, fs) * 0.5f, c.y - fs * 0.5f, fs, Color{255, 255, 255, 230});
}

void Game::drawTouchControls() {
    const TouchLayout& L = touch_.layout();

    // Джойстик: пока палец не лежит — подсказка на привычном месте.
    const bool active = touch_.stickActive();
    const float bx = active ? touch_.stickBaseX() : L.stickHintX;
    const float by = active ? touch_.stickBaseY() : L.stickHintY;
    const float kx = active ? touch_.stickKnobX() : L.stickHintX;
    const float ky = active ? touch_.stickKnobY() : L.stickHintY;
    DrawCircle(static_cast<int>(bx), static_cast<int>(by), L.stickRadius, Color{255, 255, 255, static_cast<unsigned char>(active ? 38 : 20)});
    DrawCircleLines(static_cast<int>(bx), static_cast<int>(by), L.stickRadius, Color{255, 255, 255, 120});
    DrawCircle(static_cast<int>(kx), static_cast<int>(ky), L.stickRadius * 0.38f, Color{255, 255, 255, static_cast<unsigned char>(active ? 170 : 80)});

    drawTouchButton(L.jump, touch_.jumpHeld(), false, tr("ПРЫЖОК", "JUMP"));
    drawTouchButton(L.action, touch_.actionHeld(), world_->interaction().kind != Interaction::Kind::None,
                    tr("ДЕЙСТВИЕ", "ACTION"));

    // Кнопка паузы: две палочки.
    const int px = static_cast<int>(L.pause.x), py = static_cast<int>(L.pause.y);
    DrawCircle(px, py, L.pause.r, Color{0, 0, 0, 90});
    DrawCircleLines(px, py, L.pause.r, Color{255, 255, 255, 150});
    const int bw = std::max(3, static_cast<int>(L.pause.r * 0.18f));
    const int bhh = static_cast<int>(L.pause.r * 0.8f);
    DrawRectangle(px - bw * 2, py - bhh / 2, bw, bhh, Color{255, 255, 255, 220});
    DrawRectangle(px + bw, py - bhh / 2, bw, bhh, Color{255, 255, 255, 220});
}

void Game::drawOverlays(bool portrait) {
    const int sw = GetScreenWidth(), sh = GetScreenHeight();
    const float fsh = static_cast<float>(sh);

    if (portrait) {
        DrawRectangle(0, 0, sw, sh, Color{20, 14, 10, 245});
        centered(tr("Поверните телефон", "Rotate your phone"), fsh * 0.42f, u(40.f), WHITE);
        centered(tr("Игра идёт в горизонтальном режиме", "The game plays in landscape"), fsh * 0.42f + u(56.f),
                 u(22.f), Color{220, 220, 220, 255});
        return;
    }

    if (state_ == State::Paused) {
        DrawRectangle(0, 0, sw, sh, Color{0, 0, 0, 150});
        const float top = fsh * 0.26f;
        centered(started_ ? tr("Пауза", "Paused") : "Wild West Survival", top, u(56.f), WHITE);

        float y = top + u(86.f);
        const Color soft{225, 225, 225, 255};
        if (touchMode_) {
            centered(tr("Коснитесь экрана, чтобы играть", "Tap the screen to play"), y, u(26.f), Color{255, 230, 160, 255});
            y += u(46.f);
            centered(tr("Левый палец — ходьба, до самого кольца — бег", "Left thumb: move, to the ring - sprint"), y, u(20.f), soft);
            y += u(30.f);
            centered(tr("Правый палец — осмотр, кнопки — прыжок и действие", "Right thumb: look, buttons: jump and action"), y, u(20.f), soft);
        } else {
            const char* go = started_ ? tr("Клик или Esc — продолжить", "Click or Esc - resume")
                                      : tr("Кликните, чтобы играть", "Click to play");
            centered(go, y, u(26.f), Color{255, 230, 160, 255});
            y += u(46.f);
            centered(tr("WASD — ходьба   Shift — бег   Пробел — прыжок   E — действие", "WASD - move   Shift - sprint   Space - jump   E - interact"),
                     y, u(20.f), soft);
            if (!kWeb) {
                y += u(30.f);
                centered(tr("Q — выход", "Q - quit"), y, u(20.f), soft);
            }
        }
    } else if (state_ == State::Dead) {
        DrawRectangle(0, 0, sw, sh, Color{90, 0, 0, 170});
        centered(tr("Вы погибли", "You died"), fsh * 0.3f, u(64.f), Color{255, 230, 230, 255});
        char buf[128];
        std::snprintf(buf, sizeof buf, "%s: %d   %s: %d", tr("Прожито дней", "Days survived"),
                      world_->clock().day(), tr("Рекорд", "Best"), bestDay_);
        centered(buf, fsh * 0.3f + u(90.f), u(26.f), WHITE);
        if (deadTimer_ > 0.8f)
            centered(touchMode_ ? tr("Коснитесь экрана — начать заново", "Tap the screen to start over")
                                : tr("R — начать заново", "R - start over"),
                     fsh * 0.3f + u(135.f), u(24.f), Color{255, 220, 200, 255});
    }
}

void Game::frame() {
    const float dt = GetFrameTime();
    const int sw = GetScreenWidth(), sh = GetScreenHeight();
    time_ += dt;
    ui_ = clampf(static_cast<float>(sh) / 720.f, 0.55f, 1.3f);
    hurtFlash_ = std::max(0.f, hurtFlash_ - dt * 2.5f);
    messageTimer_ = std::max(0.f, messageTimer_ - dt);

    // Сенсор: как только появилось касание, включаем экранное управление.
    std::vector<TouchPoint> touches;
    readTouches(touches);
    if (!touches.empty()) touchMode_ = true;
    if (touchMode_) touch_.update(touches, sw, sh);
    const bool portrait = touchMode_ && sh > sw;

    if (IsKeyPressed(KEY_F3)) showDebug_ = !showDebug_;
    updateState(dt, portrait);

    // Симуляция.
    if (state_ == State::Playing && !portrait) {
        PlayerInput in;
        bool interact = false;
        readPlayerInput(in, interact);
        world_->update(in, interact, dt);

        const World::FrameEvents& ev = world_->events();
        if (ev.hurt) hurtFlash_ = 1.f;
        if (ev.drank) { message_ = tr("Вы напились", "You drank"); messageTimer_ = 1.5f; }
        if (ev.ate)   { message_ = tr("Нашли припасы", "Found supplies"); messageTimer_ = 1.5f; }
        if (ev.died) {
            state_ = State::Dead;
            deadTimer_ = 0.f;
            bestDay_ = std::max(bestDay_, world_->clock().day());
            if (!touchMode_) EnableCursor();
        }
    }

    // Рисование.
    const Camera3D cam = makeCamera(dt);
    BeginDrawing();
    ClearBackground(renderer_->skyColor(*world_));
    BeginMode3D(cam);
    renderer_->drawScene(*world_, cam, time_);
    EndMode3D();

    if (!portrait) {
        drawHud();
        if (touchMode_ && state_ == State::Playing) drawTouchControls();
    }
    drawOverlays(portrait);
    EndDrawing();
}

void Game::run() {
#ifdef __EMSCRIPTEN__
    // Цикл отдаём браузеру: он вызывает кадр по requestAnimationFrame. Сюда управление не возвращается.
    emscripten_set_main_loop_arg(webFrame, this, 0, 1);
#else
    while (!WindowShouldClose() && !quit_) frame();
#endif
}

} // namespace ws
