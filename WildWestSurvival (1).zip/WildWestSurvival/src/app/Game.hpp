#pragma once
#include <memory>

#include "input/TouchControls.hpp"
#include "raylib.h"
#include "render/Renderer.hpp"
#include "sim/World.hpp"

namespace ws {

// Окно, ввод (клавиатура + мышь или сенсор), камера и HUD. Вся игровая логика живёт в World.
// Один и тот же код работает на компьютере и в браузере (в том числе на телефоне).
class Game {
public:
    Game();
    ~Game();
    Game(const Game&) = delete;
    Game& operator=(const Game&) = delete;

    void run();

    // Один кадр. Публичный, потому что в браузере его вызывает цикл Emscripten.
    void frame();

private:
    enum class State { Playing, Paused, Dead };

    void loadFont();
    const char* tr(const char* ru, const char* en) const { return cyrillic_ ? ru : en; }

    void readTouches(std::vector<TouchPoint>& out) const;
    void updateState(float dt, bool portrait);
    void readPlayerInput(PlayerInput& in, bool& interact);
    Camera3D makeCamera(float dt);

    void drawHud();
    void drawTouchControls();
    void drawOverlays(bool portrait);
    void drawBar(float x, float y, float w, float h, float value, Color fill, const char* label);
    void drawTouchButton(const TouchCircle& c, bool held, bool highlight, const char* label);
    void text(const char* s, float x, float y, float size, Color c) const;
    float textWidth(const char* s, float size) const;
    void centered(const char* s, float y, float size, Color c) const;
    const char* interactionText(Interaction::Kind k) const;
    float u(float v) const { return v * ui_; }

    std::unique_ptr<World> world_;
    std::unique_ptr<Renderer> renderer_;
    TouchControls touch_;
    State state_ = State::Playing;

    Font font_{};
    bool customFont_ = false;
    bool cyrillic_ = false;

    bool touchMode_ = false;   // включается при первом касании экрана
    bool started_ = false;     // игрок хотя бы раз начал игру (в браузере нужен клик)
    bool quit_ = false;
    bool lockSeen_ = false;    // браузер выдал захват мыши
    int  skipLook_ = 0;        // пропустить обзор несколько кадров после возврата в игру
    bool moveIntent_ = false, sprintIntent_ = false;

    float ui_ = 1.f;           // масштаб интерфейса от высоты окна
    float time_ = 0.f;
    float bobPhase_ = 0.f;
    float hurtFlash_ = 0.f;
    float deadTimer_ = 0.f;
    float messageTimer_ = 0.f;
    const char* message_ = "";
    int bestDay_ = 1;
    bool showDebug_ = false;
};

} // namespace ws
