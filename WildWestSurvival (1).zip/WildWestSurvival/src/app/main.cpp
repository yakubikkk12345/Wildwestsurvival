#include "app/Game.hpp"

int main() {
    // В браузере run() не возвращает управление (кадры вызывает requestAnimationFrame),
    // поэтому игра живёт в куче, а не на стеке main.
    ws::Game* game = new ws::Game();
    game->run();
    delete game;
    return 0;
}
