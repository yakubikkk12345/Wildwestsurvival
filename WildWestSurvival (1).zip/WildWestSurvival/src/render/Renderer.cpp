#include "render/Renderer.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>

#include "raymath.h"
#include "rlgl.h"

namespace ws {

namespace {

constexpr int kChunkCells = 32;  // 33*33 вершин на кусок: влезает в 16-битные индексы raylib

Color lerpColor(Color a, Color b, float t) {
    t = clampf(t, 0.f, 1.f);
    return Color{static_cast<unsigned char>(lerpf(a.r, b.r, t)),
                 static_cast<unsigned char>(lerpf(a.g, b.g, t)),
                 static_cast<unsigned char>(lerpf(a.b, b.b, t)),
                 static_cast<unsigned char>(lerpf(a.a, b.a, t))};
}

// Умножение цвета на подсветку (255 — без изменений).
Color shade(Color c, Color tint) {
    return Color{static_cast<unsigned char>(c.r * tint.r / 255),
                 static_cast<unsigned char>(c.g * tint.g / 255),
                 static_cast<unsigned char>(c.b * tint.b / 255), c.a};
}

float hashf(int x, int y) {
    std::uint32_t h = static_cast<std::uint32_t>(x) * 374761393u + static_cast<std::uint32_t>(y) * 668265263u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return static_cast<float>(h & 0xFFFFu) / 65535.f;
}

Vector3 V(const Vec3& v) { return Vector3{v.x, v.y, v.z}; }

} // namespace

Renderer::Renderer(const World& world) {
    material_ = LoadMaterialDefault();
    buildTerrainMeshes(world);

    // Звёзды: фиксированные точки на небесной сфере.
    for (int i = 0; i < 160; ++i) {
        const float a = hashf(i, 1) * 2.f * kPi;
        const float e = 0.08f + hashf(i, 2) * 1.2f;
        stars_.push_back(Vector3{std::cos(a) * std::cos(e), std::sin(e), std::sin(a) * std::cos(e)});
    }
}

Renderer::~Renderer() {
    for (Mesh& m : chunks_) UnloadMesh(m);
    UnloadMaterial(material_);
}

void Renderer::buildTerrainMeshes(const World& world) {
    const Terrain& t = world.terrain();
    const int n = t.vertsPerSide();
    const Vector3 sunDir = Vector3Normalize(Vector3{0.5f, 0.8f, 0.3f});

    const Color sand{214, 184, 128, 255};
    const Color sandDark{190, 150, 100, 255};
    const Color rock{168, 104, 74, 255};
    const Color grass{112, 146, 76, 255};

    auto vertexColor = [&](int ix, int iz) -> Color {
        const float x = t.vertexCoord(ix), z = t.vertexCoord(iz);
        const float h = t.vertexHeight(ix, iz);
        const float slope = t.slopeAt(x, z);

        Color c = lerpColor(sand, sandDark, hashf(ix, iz) * 0.6f + clampf(h / 20.f, 0.f, 1.f) * 0.3f);
        // Крутые склоны и плато — красная порода.
        c = lerpColor(c, rock, smoothstep(0.35f, 0.9f, slope) + smoothstep(9.f, 15.f, h) * 0.6f);
        // Трава вокруг оазисов.
        for (const Oasis& o : world.oases()) {
            const float d = std::hypot(x - o.center.x, z - o.center.z);
            c = lerpColor(c, grass, 1.f - smoothstep(o.radius, o.shoreRadius + 6.f, d));
        }
        // Утоптанная земля вокруг лагеря.
        const float dc = std::hypot(x - world.campPosition().x, z - world.campPosition().z);
        c = lerpColor(c, Color{150, 120, 85, 255}, 1.f - smoothstep(6.f, 18.f, dc));

        const Vec3 nrm = t.normalAt(x, z);
        const float light = 0.55f + 0.45f * std::max(0.f, nrm.x * sunDir.x + nrm.y * sunDir.y + nrm.z * sunDir.z);
        return Color{static_cast<unsigned char>(c.r * light), static_cast<unsigned char>(c.g * light),
                     static_cast<unsigned char>(c.b * light), 255};
    };

    for (int cz0 = 0; cz0 < t.cells(); cz0 += kChunkCells) {
        for (int cx0 = 0; cx0 < t.cells(); cx0 += kChunkCells) {
            const int cw = std::min(kChunkCells, t.cells() - cx0);
            const int ch = std::min(kChunkCells, t.cells() - cz0);
            const int vw = cw + 1, vh = ch + 1;

            Mesh mesh{};
            mesh.vertexCount = vw * vh;
            mesh.triangleCount = cw * ch * 2;
            mesh.vertices = static_cast<float*>(MemAlloc(static_cast<unsigned>(mesh.vertexCount) * 3 * sizeof(float)));
            mesh.normals = static_cast<float*>(MemAlloc(static_cast<unsigned>(mesh.vertexCount) * 3 * sizeof(float)));
            mesh.texcoords = static_cast<float*>(MemAlloc(static_cast<unsigned>(mesh.vertexCount) * 2 * sizeof(float)));
            mesh.colors = static_cast<unsigned char*>(MemAlloc(static_cast<unsigned>(mesh.vertexCount) * 4));
            mesh.indices = static_cast<unsigned short*>(MemAlloc(static_cast<unsigned>(mesh.triangleCount) * 3 * sizeof(unsigned short)));

            int v = 0;
            for (int j = 0; j < vh; ++j) {
                for (int i = 0; i < vw; ++i, ++v) {
                    const int ix = cx0 + i, iz = cz0 + j;
                    const float x = t.vertexCoord(ix), z = t.vertexCoord(iz);
                    const Vec3 nrm = t.normalAt(x, z);
                    mesh.vertices[v * 3 + 0] = x;
                    mesh.vertices[v * 3 + 1] = t.vertexHeight(ix, iz);
                    mesh.vertices[v * 3 + 2] = z;
                    mesh.normals[v * 3 + 0] = nrm.x;
                    mesh.normals[v * 3 + 1] = nrm.y;
                    mesh.normals[v * 3 + 2] = nrm.z;
                    mesh.texcoords[v * 2 + 0] = static_cast<float>(ix) / static_cast<float>(n);
                    mesh.texcoords[v * 2 + 1] = static_cast<float>(iz) / static_cast<float>(n);
                    const Color c = vertexColor(ix, iz);
                    mesh.colors[v * 4 + 0] = c.r;
                    mesh.colors[v * 4 + 1] = c.g;
                    mesh.colors[v * 4 + 2] = c.b;
                    mesh.colors[v * 4 + 3] = 255;
                }
            }

            // Диагональ клетки — от (i+1, j) к (i, j+1): та же, что в Terrain::heightAt.
            int k = 0;
            for (int j = 0; j < ch; ++j) {
                for (int i = 0; i < cw; ++i) {
                    const unsigned short a = static_cast<unsigned short>(j * vw + i);
                    const unsigned short b = static_cast<unsigned short>(a + 1);
                    const unsigned short c = static_cast<unsigned short>(a + vw);
                    const unsigned short d = static_cast<unsigned short>(c + 1);
                    mesh.indices[k++] = a; mesh.indices[k++] = c; mesh.indices[k++] = b;
                    mesh.indices[k++] = d; mesh.indices[k++] = b; mesh.indices[k++] = c;
                }
            }

            UploadMesh(&mesh, false);
            chunks_.push_back(mesh);
        }
    }
}

Color Renderer::skyColor(const World& world) const {
    const float day = world.clock().daylight();
    const Color night{6, 8, 22, 255};
    const Color noon{128, 188, 236, 255};
    Color c = lerpColor(night, noon, day);
    // Рассвет и закат: тёплая полоса, пока солнце у горизонта.
    const float warm = 1.f - std::fabs(day - 0.5f) * 2.f;
    return lerpColor(c, Color{238, 132, 84, 255}, clampf(warm, 0.f, 1.f) * 0.55f);
}

Color Renderer::worldTint(const World& world) const {
    const float day = world.clock().daylight();
    return lerpColor(Color{62, 72, 120, 255}, Color{255, 252, 245, 255}, std::pow(day, 0.7f));
}

void Renderer::drawSky(const World& world, const Vector3& eye, float time) const {
    (void)time;
    const float a = world.clock().sunAngle();
    const float day = world.clock().daylight();

    // Звёзды видны ночью.
    if (day < 0.5f) {
        const unsigned char alpha = static_cast<unsigned char>((1.f - day * 2.f) * 255.f);
        for (const Vector3& s : stars_)
            DrawPoint3D(Vector3Add(eye, Vector3Scale(s, 420.f)), Color{255, 255, 240, alpha});
    }

    // Солнце идёт с востока (+X) на запад (-X); луна напротив.
    const Vector3 dir = Vector3Normalize(Vector3{std::cos(a), std::sin(a), 0.3f});
    if (dir.y > -0.04f) {
        const Vector3 p = Vector3Add(eye, Vector3Scale(dir, 450.f));
        DrawSphere(p, 20.f, Color{255, 236, 170, 255});
    }
    if (-dir.y > -0.04f) {
        const Vector3 p = Vector3Add(eye, Vector3Scale(Vector3Negate(dir), 450.f));
        DrawSphere(p, 12.f, Color{226, 232, 245, 255});
    }
}

void Renderer::drawScene(const World& world, const Camera3D& camera, float time) const {
    const Color tint = worldTint(world);
    const Vector3 eye = camera.position;

    drawSky(world, eye, time);

    // За краем карты — плоская пустыня на уровне края, чтобы не было пустоты.
    DrawPlane(Vector3{0.f, -0.03f, 0.f}, Vector2{4000.f, 4000.f}, shade(Color{190, 160, 112, 255}, tint));

    material_.maps[MATERIAL_MAP_DIFFUSE].color = tint;
    for (const Mesh& m : chunks_) DrawMesh(m, material_, MatrixIdentity());

    const float maxD2 = propDrawDistance_ * propDrawDistance_;
    for (const Prop& p : world.props()) {
        // Далёкую мелочь не рисуем.
        const float dx = p.pos.x - eye.x, dz = p.pos.z - eye.z;
        if (dx * dx + dz * dz > maxD2) continue;
        drawProp(p, tint, time);
    }
    for (const Oasis& o : world.oases()) drawOasis(o, tint, time);
}

void Renderer::drawOasis(const Oasis& o, Color tint, float time) const {
    const float ripple = std::sin(time * 1.4f + o.center.x) * 0.015f;
    const Vector3 c{o.center.x, o.center.y + ripple, o.center.z};
    DrawCylinder(c, o.radius, o.radius, 0.04f, 48, shade(Color{52, 132, 178, 235}, tint));

    // Пальмоподобные деревья вокруг воды — детерминированно от положения оазиса.
    for (int i = 0; i < 7; ++i) {
        const float ang = hashf(static_cast<int>(o.center.x), i) * 2.f * kPi;
        const float r = o.radius + 2.5f + hashf(i, static_cast<int>(o.center.z)) * 3.f;
        const float x = o.center.x + std::cos(ang) * r, z = o.center.z + std::sin(ang) * r;
        const float base = o.center.y + 0.55f;  // берег на уровне baseH
        const float h = 4.5f + hashf(i, 9) * 2.f;
        DrawCylinder(Vector3{x, base, z}, 0.18f, 0.26f, h, 7, shade(Color{120, 88, 56, 255}, tint));
        DrawSphere(Vector3{x, base + h + 0.3f, z}, 1.5f, shade(Color{70, 130, 58, 255}, tint));
    }
}

void Renderer::drawProp(const Prop& p, Color tint, float time) const {
    const Vector3 pos = V(p.pos);
    const float deg = p.rotation * 180.f / kPi;

    switch (p.type) {
        case PropType::Cactus: {
            const Color green = shade(Color{60, 130, 72, 255}, tint);
            const Color dark = shade(Color{44, 100, 56, 255}, tint);
            const float h = p.harvested ? p.height * 0.3f : p.height;
            const float r = 0.22f * p.scale;
            DrawCylinder(pos, r * 0.9f, r, h, 8, green);
            if (!p.harvested) {
                rlPushMatrix();
                rlTranslatef(pos.x, pos.y, pos.z);
                rlRotatef(deg, 0.f, 1.f, 0.f);
                // Две "руки": горизонтальный отросток и вертикальная часть.
                DrawCube(Vector3{r * 1.8f, h * 0.45f, 0.f}, r * 2.6f, r * 1.1f, r * 1.1f, dark);
                DrawCylinder(Vector3{r * 2.8f, h * 0.45f, 0.f}, r * 0.5f, r * 0.55f, h * 0.35f, 7, dark);
                DrawCube(Vector3{-r * 1.6f, h * 0.62f, 0.f}, r * 2.2f, r * 1.0f, r * 1.0f, dark);
                DrawCylinder(Vector3{-r * 2.5f, h * 0.62f, 0.f}, r * 0.5f, r * 0.55f, h * 0.28f, 7, dark);
                rlPopMatrix();
            }
            break;
        }
        case PropType::Rock: {
            rlPushMatrix();
            rlTranslatef(pos.x, pos.y + p.scale * 0.3f, pos.z);
            rlRotatef(deg, 0.f, 1.f, 0.f);
            rlScalef(1.f, 0.65f, 0.85f);
            DrawSphereEx(Vector3{0.f, 0.f, 0.f}, p.scale * 0.9f, 7, 8, shade(Color{138, 112, 96, 255}, tint));
            rlPopMatrix();
            break;
        }
        case PropType::DeadTree: {
            const Color wood = shade(Color{96, 74, 54, 255}, tint);
            DrawCylinder(pos, 0.12f * p.scale, 0.28f * p.scale, p.height, 6, wood);
            rlPushMatrix();
            rlTranslatef(pos.x, pos.y + p.height * 0.7f, pos.z);
            rlRotatef(deg, 0.f, 1.f, 0.f);
            rlRotatef(50.f, 0.f, 0.f, 1.f);
            DrawCylinder(Vector3{0.f, 0.f, 0.f}, 0.04f, 0.09f * p.scale, p.height * 0.45f, 5, wood);
            rlPopMatrix();
            rlPushMatrix();
            rlTranslatef(pos.x, pos.y + p.height * 0.5f, pos.z);
            rlRotatef(deg + 180.f, 0.f, 1.f, 0.f);
            rlRotatef(-45.f, 0.f, 0.f, 1.f);
            DrawCylinder(Vector3{0.f, 0.f, 0.f}, 0.04f, 0.08f * p.scale, p.height * 0.35f, 5, wood);
            rlPopMatrix();
            break;
        }
        case PropType::Tent: {
            rlPushMatrix();
            rlTranslatef(pos.x, pos.y, pos.z);
            rlRotatef(deg, 0.f, 1.f, 0.f);
            // Пирамида из 4 граней, повёрнута на 45° — грани смотрят по осям.
            rlRotatef(45.f, 0.f, 1.f, 0.f);
            DrawCylinder(Vector3{0.f, 0.f, 0.f}, 0.f, 2.9f * p.scale, p.height, 4, shade(Color{206, 190, 150, 255}, tint));
            rlPopMatrix();
            break;
        }
        case PropType::Campfire: {
            const Color log = shade(Color{84, 58, 38, 255}, tint);
            for (int i = 0; i < 4; ++i) {
                rlPushMatrix();
                rlTranslatef(pos.x, pos.y + 0.12f, pos.z);
                rlRotatef(45.f * static_cast<float>(i), 0.f, 1.f, 0.f);
                DrawCube(Vector3{0.f, 0.f, 0.f}, 1.2f, 0.18f, 0.18f, log);
                rlPopMatrix();
            }
            // Пламя мерцает, не зависит от освещения мира — светит само.
            const float f = 0.85f + 0.15f * std::sin(time * 17.f) + 0.08f * std::sin(time * 31.f);
            DrawCylinder(Vector3{pos.x, pos.y + 0.15f, pos.z}, 0.f, 0.32f, 0.9f * f, 7, Color{255, 150, 40, 235});
            DrawCylinder(Vector3{pos.x, pos.y + 0.15f, pos.z}, 0.f, 0.16f, 0.6f * f, 7, Color{255, 230, 120, 240});
            break;
        }
        case PropType::Barrel: {
            DrawCylinder(pos, 0.5f, 0.55f, 1.0f, 12, shade(Color{120, 80, 48, 255}, tint));
            DrawCylinder(Vector3{pos.x, pos.y + 0.98f, pos.z}, 0.46f, 0.46f, 0.04f, 12, shade(Color{58, 120, 170, 255}, tint));
            break;
        }
        case PropType::Crate: {
            rlPushMatrix();
            rlTranslatef(pos.x, pos.y + 0.45f, pos.z);
            rlRotatef(deg, 0.f, 1.f, 0.f);
            const Color wood = p.harvested ? shade(Color{100, 76, 52, 255}, tint) : shade(Color{150, 110, 66, 255}, tint);
            DrawCube(Vector3{0.f, 0.f, 0.f}, 1.0f, 0.9f, 1.0f, wood);
            DrawCubeWires(Vector3{0.f, 0.f, 0.f}, 1.0f, 0.9f, 1.0f, shade(Color{70, 48, 30, 255}, tint));
            rlPopMatrix();
            break;
        }
        case PropType::Count:
            break;
    }
}

} // namespace ws
