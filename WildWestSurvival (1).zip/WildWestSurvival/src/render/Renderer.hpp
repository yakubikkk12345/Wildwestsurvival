#pragma once
#include <vector>

#include "raylib.h"
#include "sim/World.hpp"

namespace ws {

// Рисует мир по состоянию симуляции. Только читает World, ничего в нём не меняет.
// Создавать можно лишь после InitWindow (загружает меши на видеокарту).
class Renderer {
public:
    explicit Renderer(const World& world);
    ~Renderer();
    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    // Цвет неба — им же Game закрашивает фон кадра.
    Color skyColor(const World& world) const;
    // Рисует всю 3D-сцену. Вызывать между BeginMode3D и EndMode3D.
    void drawScene(const World& world, const Camera3D& camera, float time) const;

    // Дальше этого расстояния (метры) мелкие объекты не рисуются. Меньше — быстрее (телефоны).
    void setPropDrawDistance(float meters) { propDrawDistance_ = meters; }

private:
    void buildTerrainMeshes(const World& world);
    Color worldTint(const World& world) const;
    void drawSky(const World& world, const Vector3& eye, float time) const;
    void drawProp(const Prop& p, Color tint, float time) const;
    void drawOasis(const Oasis& o, Color tint, float time) const;

    std::vector<Mesh> chunks_;
    Material material_{};
    std::vector<Vector3> stars_;
    float propDrawDistance_ = 200.f;
};

} // namespace ws
