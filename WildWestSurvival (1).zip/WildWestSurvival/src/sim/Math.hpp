#pragma once
#include <cmath>

namespace ws {

constexpr float kPi = 3.14159265358979323846f;

struct Vec3 {
    float x = 0.f, y = 0.f, z = 0.f;
    constexpr Vec3() = default;
    constexpr Vec3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
};

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }

inline float smoothstep(float e0, float e1, float x) {
    const float t = clampf((x - e0) / (e1 - e0), 0.f, 1.f);
    return t * t * (3.f - 2.f * t);
}

// Расстояние в горизонтальной плоскости (высоту не учитываем).
inline float distXZ(const Vec3& a, const Vec3& b) { return std::hypot(a.x - b.x, a.z - b.z); }

} // namespace ws
