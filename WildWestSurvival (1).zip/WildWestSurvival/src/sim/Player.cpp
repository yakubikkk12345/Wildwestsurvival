#include "sim/Player.hpp"

#include <algorithm>
#include <cmath>

#include "sim/Terrain.hpp"

namespace ws {

Vec3 Player::forward() const {
    const float cp = std::cos(pitch_);
    return Vec3(cp * std::sin(yaw_), std::sin(pitch_), cp * std::cos(yaw_));
}

void Player::teleport(const Terrain& terrain, float x, float z) {
    pos_ = Vec3(x, terrain.heightAt(x, z), z);
    vx_ = vy_ = vz_ = 0.f;
    grounded_ = true;
}

void Player::setPosition(const Vec3& p) {
    pos_ = p;
    vx_ = vy_ = vz_ = 0.f;
    grounded_ = false;
}

bool Player::blocked(const Terrain& terrain, float nx, float nz) const {
    const float dx = nx - pos_.x, dz = nz - pos_.z;
    const float d = std::sqrt(dx * dx + dz * dz);
    if (d < 1e-5f) return false;
    const float hTo = terrain.heightAt(nx, nz);
    // На земле: слишком крутой подъём — стена.
    if (grounded_) return (hTo - terrain.heightAt(pos_.x, pos_.z)) / d > kMaxSlope;
    // В воздухе: нельзя пройти сквозь склон.
    return hTo > pos_.y + 0.3f;
}

PlayerFrame Player::update(const PlayerInput& in, const Terrain& terrain, bool canSprint, float dt) {
    PlayerFrame out;

    // Взгляд. Вправо по мыши = уменьшение yaw (см. Player::forward).
    yaw_ -= in.lookYaw;
    pitch_ = clampf(pitch_ - in.lookPitch, -1.5f, 1.5f);

    // Желаемое направление в мире.
    const float sy = std::sin(yaw_), cy = std::cos(yaw_);
    float wx = sy * in.moveForward + (-cy) * in.moveRight;
    float wz = cy * in.moveForward + sy * in.moveRight;
    const float len = std::sqrt(wx * wx + wz * wz);
    out.moving = len > 0.01f;
    if (len > 1.f) {
        wx /= len;
        wz /= len;
    }

    out.sprinting = out.moving && in.sprint && canSprint;
    const float speed = out.sprinting ? kSprintSpeed : kWalkSpeed;

    // Плавный разгон: на земле резкий, в воздухе почти инерция.
    const float k = std::min(1.f, (grounded_ ? 14.f : 2.f) * dt);
    vx_ += (wx * speed - vx_) * k;
    vz_ += (wz * speed - vz_) * k;

    // Шаг по горизонтали с "скольжением" вдоль препятствий.
    const float limit = terrain.halfSize() - 15.f;
    const float nx = clampf(pos_.x + vx_ * dt, -limit, limit);
    const float nz = clampf(pos_.z + vz_ * dt, -limit, limit);
    if (!blocked(terrain, nx, nz)) {
        pos_.x = nx;
        pos_.z = nz;
    } else if (!blocked(terrain, nx, pos_.z)) {
        pos_.x = nx;
        vz_ = 0.f;
    } else if (!blocked(terrain, pos_.x, nz)) {
        pos_.z = nz;
        vx_ = 0.f;
    } else {
        vx_ = vz_ = 0.f;
    }

    // Вертикаль: прилипаем к земле, прыгаем, падаем.
    const float ground = terrain.heightAt(pos_.x, pos_.z);
    if (grounded_) {
        if (ground < pos_.y - kStickDistance) {
            grounded_ = false;  // сошли с обрыва
        } else {
            pos_.y = ground;
            vy_ = 0.f;
            if (in.jump) {
                vy_ = kJumpSpeed;
                grounded_ = false;
            }
        }
    }
    if (!grounded_) {
        vy_ -= kGravity * dt;
        pos_.y += vy_ * dt;
        if (pos_.y <= ground && vy_ <= 0.f) {
            out.landed = true;
            out.impactSpeed = -vy_;
            pos_.y = ground;
            vy_ = 0.f;
            grounded_ = true;
        }
    }
    return out;
}

} // namespace ws
