#include "sim/Survival.hpp"

#include <algorithm>

#include "sim/Math.hpp"

namespace ws {

void Survival::update(float dt, const SurvivalContext& ctx) {
    if (dead()) return;
    const SurvivalTuning& t = tuning;

    // Жара выше 30 °C ускоряет жажду, холод ниже 10 °C — голод.
    const float heat = clampf((ctx.ambientTempC - 30.f) / 10.f, 0.f, 1.5f);
    const float cold = clampf((10.f - ctx.ambientTempC) / 10.f, 0.f, 1.f);
    const float activity = ctx.sprinting ? 2.f : (ctx.moving ? 1.25f : 1.f);

    water = clampf(water - t.waterDrain * activity * (1.f + heat * 1.5f) * dt, 0.f, kMax);
    food  = clampf(food  - t.foodDrain  * activity * (1.f + cold * 0.5f) * dt, 0.f, kMax);

    // Выносливость.
    if (ctx.sprinting) {
        stamina -= t.sprintCost * dt;
        if (stamina <= 0.f) {
            stamina = 0.f;
            exhausted = true;
        }
    } else {
        float regen = ctx.moving ? t.staminaRegenMoving : t.staminaRegenIdle;
        if (water < 20.f) regen *= 0.5f;
        stamina = std::min(kMax, stamina + regen * dt);
        if (exhausted && stamina >= t.exhaustedUntil) exhausted = false;
    }

    // Здоровье.
    float dmg = 0.f;
    if (water <= 0.f) dmg += t.starveDamage;
    if (food  <= 0.f) dmg += t.starveDamage;
    if (ctx.ambientTempC > 36.f && water < 25.f) dmg += t.heatstrokeDamage;

    if (dmg > 0.f)
        health -= dmg * dt;
    else if (food > 50.f && water > 50.f)
        health += t.healthRegen * dt;
    health = clampf(health, 0.f, kMax);
}

void Survival::eat(float amount)   { food  = clampf(food  + amount, 0.f, kMax); }
void Survival::drink(float amount) { water = clampf(water + amount, 0.f, kMax); }
void Survival::damage(float amount) { health = clampf(health - amount, 0.f, kMax); }

void Survival::reset() { *this = Survival(); }

} // namespace ws
