#include "sim/World.hpp"

#include <algorithm>
#include <cmath>

namespace ws {

namespace {

// Небольшой детерминированный генератор (xorshift32): один и тот же seed — тот же мир.
std::uint32_t nextRand(std::uint32_t& s) {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
}
float rand01(std::uint32_t& s) { return static_cast<float>(nextRand(s) & 0xFFFFFFu) / 16777215.f; }
float randRange(std::uint32_t& s, float a, float b) { return a + (b - a) * rand01(s); }

constexpr float kInteractRange = 3.2f;
constexpr float kCactusRange = 2.4f;
constexpr float kLookCone = 0.80f;  // косинус угла, в котором "смотрим на объект"

} // namespace

World::World(const WorldConfig& cfg)
    : cfg_(cfg),
      terrain_(cfg.cells, cfg.cellSize, cfg.seed),
      clock_(cfg.dayLengthSeconds, cfg.startHour) {
    generate();
    respawn();
}

void World::respawn() {
    clock_ = WorldClock(cfg_.dayLengthSeconds, cfg_.startHour);
    survival_.reset();
    player_.teleport(terrain_, camp_.x + 6.f, camp_.z + 6.f);
    interaction_ = Interaction();
    events_ = FrameEvents();
    cactusHurtCooldown_ = 0.f;
}

float World::distToNearestOasis(float x, float z) const {
    float best = 1e9f;
    for (const Oasis& o : oases_)
        best = std::min(best, std::hypot(x - o.center.x, z - o.center.z));
    return best;
}

bool World::inOasisWater(float x, float z) const {
    for (const Oasis& o : oases_)
        if (std::hypot(x - o.center.x, z - o.center.z) < o.radius) return true;
    return false;
}

bool World::freeSpot(float x, float z, float margin) const {
    for (const Prop& p : props_)
        if (std::hypot(x - p.pos.x, z - p.pos.z) < p.radius + margin) return false;
    return true;
}

void World::generate() {
    std::uint32_t rng = cfg_.seed * 2654435761u + 1u;
    if (rng == 0) rng = 1u;
    const float limit = terrain_.halfSize() - 40.f;

    // Лагерь у центра: выравниваем площадку.
    camp_ = Vec3(0.f, 0.f, 0.f);
    const float campH = terrain_.heightAt(0.f, 0.f);
    terrain_.flatten(0.f, 0.f, 14.f, 30.f, campH);
    camp_.y = terrain_.heightAt(0.f, 0.f);

    // Оазисы: подальше от лагеря и друг от друга.
    int guard = 0;
    while (static_cast<int>(oases_.size()) < cfg_.oasisCount && guard++ < 500) {
        const float x = randRange(rng, -limit, limit);
        const float z = randRange(rng, -limit, limit);
        if (std::hypot(x, z) < 90.f) continue;
        bool tooClose = false;
        for (const Oasis& o : oases_)
            if (std::hypot(x - o.center.x, z - o.center.z) < 110.f) tooClose = true;
        if (tooClose) continue;

        Oasis o;
        o.radius = randRange(rng, 9.f, 14.f);
        o.shoreRadius = o.radius + 7.f;
        const float baseH = terrain_.heightAt(x, z);
        // Берег ровный, вода чуть ниже него.
        terrain_.flatten(x, z, o.shoreRadius * 0.7f, o.shoreRadius + 14.f, baseH);
        // Чаша подобрана так, чтобы рельеф уходил под воду ровно на радиусе водной глади.
        terrain_.carve(x, z, std::max(0.f, o.radius - 5.3f), o.radius + 4.f, 1.4f);
        o.center = Vec3(x, baseH - 0.55f, z);
        oases_.push_back(o);
    }

    placeProps(rng);
}

void World::placeProps(std::uint32_t& rng) {
    auto add = [&](PropType type, float x, float z, float scale, float radius, float height) {
        Prop p;
        p.type = type;
        p.pos = Vec3(x, terrain_.heightAt(x, z), z);
        p.scale = scale;
        p.rotation = randRange(rng, 0.f, 2.f * kPi);
        p.radius = radius;
        p.height = height;
        props_.push_back(p);
    };

    // Лагерь: костёр в центре, палатка, бочка и ящик вокруг.
    add(PropType::Campfire, 0.f, 0.f, 1.f, 0.f, 0.6f);
    add(PropType::Tent,   -5.5f, -3.0f, 1.f, 2.2f, 2.0f);
    add(PropType::Barrel,  3.5f, -2.5f, 1.f, 0.55f, 1.0f);
    add(PropType::Crate,   2.0f,  3.8f, 1.f, 0.6f, 0.9f);
    add(PropType::Crate,  -2.8f,  4.6f, 1.f, 0.6f, 0.9f);

    const float limit = terrain_.halfSize() - 30.f;

    auto scatter = [&](PropType type, int count, float minScale, float maxScale,
                       float radiusPerScale, float heightPerScale, float minCamp) {
        int placed = 0, tries = 0;
        while (placed < count && tries++ < count * 30) {
            const float x = randRange(rng, -limit, limit);
            const float z = randRange(rng, -limit, limit);
            if (std::hypot(x, z) < minCamp) continue;
            if (terrain_.slopeAt(x, z) > 0.8f) continue;  // не на скалах и обрывах
            // Не в воде и не на берегу оазиса.
            bool nearOasis = false;
            for (const Oasis& o : oases_)
                if (std::hypot(x - o.center.x, z - o.center.z) < o.shoreRadius + 2.f) nearOasis = true;
            if (nearOasis) continue;
            const float s = randRange(rng, minScale, maxScale);
            if (!freeSpot(x, z, radiusPerScale * s + 1.2f)) continue;
            add(type, x, z, s, radiusPerScale * s, heightPerScale * s);
            ++placed;
        }
    };

    scatter(PropType::Cactus,   cfg_.cactusCount,   0.8f, 1.8f, 0.45f, 2.6f, 32.f);
    scatter(PropType::Rock,     cfg_.rockCount,     0.7f, 2.6f, 0.9f,  0.9f, 28.f);
    scatter(PropType::DeadTree, cfg_.deadTreeCount, 0.9f, 1.5f, 0.35f, 3.2f, 30.f);
}

void World::pushOutOfProps() {
    Vec3 p = player_.position();
    const float playerR = 0.35f;
    for (const Prop& pr : props_) {
        if (pr.radius <= 0.f || pr.harvested) continue;
        const float dx = p.x - pr.pos.x, dz = p.z - pr.pos.z;
        const float d = std::sqrt(dx * dx + dz * dz);
        const float minD = pr.radius + playerR;
        if (d < minD && d > 1e-4f) {
            p.x = pr.pos.x + dx / d * minD;
            p.z = pr.pos.z + dz / d * minD;
        }
    }
    player_.nudge(p.x, p.z);
}

void World::updateInteraction() {
    interaction_ = Interaction();
    const Vec3 eye = player_.eyePosition();
    const Vec3 fwd = player_.forward();

    // Вода оазиса: стоим у берега (в пределах дальности от водной глади).
    for (const Oasis& o : oases_) {
        const float d = std::hypot(eye.x - o.center.x, eye.z - o.center.z);
        if (d < o.radius + 2.8f) {
            interaction_.kind = Interaction::Kind::DrinkOasis;
            return;
        }
    }

    // Объекты: ближайший в конусе взгляда.
    int best = -1;
    float bestScore = -1.f;
    for (std::size_t i = 0; i < props_.size(); ++i) {
        const Prop& pr = props_[i];
        const bool usable = pr.type == PropType::Barrel || pr.type == PropType::Crate ||
                            (pr.type == PropType::Cactus && !pr.harvested);
        if (!usable) continue;
        const float tx = pr.pos.x - eye.x;
        const float ty = pr.pos.y + pr.height * 0.5f - eye.y;
        const float tz = pr.pos.z - eye.z;
        const float dist = std::sqrt(tx * tx + ty * ty + tz * tz);
        if (dist > kInteractRange || dist < 1e-3f) continue;
        const float dotv = (tx * fwd.x + ty * fwd.y + tz * fwd.z) / dist;
        if (dotv < kLookCone) continue;
        const float score = dotv - dist * 0.05f;
        if (score > bestScore) {
            bestScore = score;
            best = static_cast<int>(i);
        }
    }
    if (best >= 0) {
        const Prop& pr = props_[static_cast<std::size_t>(best)];
        interaction_.propIndex = best;
        switch (pr.type) {
            case PropType::Barrel:
                interaction_.kind = Interaction::Kind::DrinkBarrel;
                break;
            case PropType::Crate:
                // Пустой ящик: подсказки нет.
                interaction_.kind = pr.harvested ? Interaction::Kind::None : Interaction::Kind::Loot;
                break;
            case PropType::Cactus:
                interaction_.kind = Interaction::Kind::Cactus;
                break;
            default:
                break;
        }
    }
}

void World::doInteract() {
    using K = Interaction::Kind;
    switch (interaction_.kind) {
        case K::DrinkOasis:
            survival_.drink(40.f);
            events_.drank = true;
            break;
        case K::DrinkBarrel:
            survival_.drink(25.f);
            events_.drank = true;
            break;
        case K::Loot: {
            Prop& pr = props_[static_cast<std::size_t>(interaction_.propIndex)];
            if (!pr.harvested) {
                pr.harvested = true;
                pr.respawnIn = 240.f;
                survival_.eat(35.f);
                survival_.drink(10.f);
                events_.ate = true;
            }
            break;
        }
        case K::Cactus: {
            Prop& pr = props_[static_cast<std::size_t>(interaction_.propIndex)];
            if (!pr.harvested) {
                pr.harvested = true;
                pr.respawnIn = 180.f;
                survival_.drink(12.f + 4.f * pr.scale);
                survival_.damage(3.f);  // всё-таки колючки
                events_.drank = true;
                events_.hurt = true;
            }
            break;
        }
        case K::None:
            break;
    }
}

void World::update(const PlayerInput& input, bool interact, float dt) {
    events_ = FrameEvents();
    dt = clampf(dt, 0.f, 0.1f);

    if (survival_.dead()) return;  // кадр смерти: ждём respawn() от Game

    clock_.update(dt);

    // Игрок и столкновения.
    const PlayerFrame pf = player_.update(input, terrain_, survival_.canSprint(), dt);
    pushOutOfProps();
    if (pf.landed) {
        events_.landed = true;
        if (pf.impactSpeed > 13.f) {  // сильное падение с обрыва
            survival_.damage((pf.impactSpeed - 13.f) * 6.f);
            events_.hurt = true;
        }
    }

    // Колючки: стоим вплотную к кактусу — царапает.
    cactusHurtCooldown_ = std::max(0.f, cactusHurtCooldown_ - dt);
    if (cactusHurtCooldown_ <= 0.f) {
        const Vec3& p = player_.position();
        for (const Prop& pr : props_) {
            if (pr.type != PropType::Cactus || pr.harvested) continue;
            if (std::hypot(p.x - pr.pos.x, p.z - pr.pos.z) < pr.radius + 0.35f + 0.25f) {
                survival_.damage(4.f);
                cactusHurtCooldown_ = 0.8f;
                events_.hurt = true;
                break;
            }
        }
    }

    // Выживание.
    SurvivalContext ctx;
    ctx.moving = pf.moving;
    ctx.sprinting = pf.sprinting;
    ctx.ambientTempC = clock_.ambientTemperature();
    // У костра ночью теплее.
    if (distXZ(player_.position(), camp_) < 7.f) ctx.ambientTempC += 8.f;
    // В воде оазиса прохладно.
    if (inOasisWater(player_.position().x, player_.position().z)) ctx.ambientTempC -= 8.f;
    survival_.update(dt, ctx);

    // Восстановление кактусов и ящиков.
    for (Prop& pr : props_) {
        if (!pr.harvested) continue;
        pr.respawnIn -= dt;
        if (pr.respawnIn <= 0.f) pr.harvested = false;
    }

    updateInteraction();
    if (interact) doInteract();

    if (survival_.dead()) {
        events_.died = true;
        ++deaths_;
    }
}

} // namespace ws
