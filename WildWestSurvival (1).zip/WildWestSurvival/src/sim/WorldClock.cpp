#include "sim/WorldClock.hpp"

#include <cmath>

#include "sim/Math.hpp"

namespace ws {

namespace {
// Высота солнца над горизонтом: -1 (полночь) .. 1 (полдень).
float elevation(float hour) { return std::sin((hour - 6.f) / 12.f * kPi); }
} // namespace

WorldClock::WorldClock(float dayLengthSeconds, float startHour)
    : dayLength_(dayLengthSeconds > 1.f ? dayLengthSeconds : 1.f), hour_(startHour) {}

void WorldClock::update(float dt) {
    hour_ += dt * 24.f / dayLength_;
    while (hour_ >= 24.f) {
        hour_ -= 24.f;
        ++day_;
    }
}

float WorldClock::sunAngle() const { return (hour_ - 6.f) / 12.f * kPi; }

float WorldClock::daylight() const { return smoothstep(-0.12f, 0.30f, elevation(hour_)); }

float WorldClock::ambientTemperature() const {
    return 6.f + 34.f * smoothstep(-0.3f, 0.8f, elevation(hour_));
}

} // namespace ws
