#pragma once

namespace ws {

// Что происходит с персонажем в этом кадре — от этого зависят расходы.
struct SurvivalContext {
    bool  moving = false;
    bool  sprinting = false;
    float ambientTempC = 20.f;
};

// Все числа баланса в одном месте, чтобы удобно крутить.
struct SurvivalTuning {
    float waterDrain         = 0.12f;  // воды в секунду (полный запас ~14 мин покоя)
    float foodDrain          = 0.06f;  // еды в секунду
    float sprintCost         = 22.f;   // выносливости в секунду на бегу
    float staminaRegenIdle   = 16.f;
    float staminaRegenMoving = 8.f;
    float exhaustedUntil     = 30.f;   // после "выдоха" бегать можно, когда выносливость выше
    float starveDamage       = 2.f;    // здоровья в секунду за каждый нулевой запас
    float heatstrokeDamage   = 0.6f;   // тепловой удар: жара + мало воды
    float healthRegen        = 1.f;
};

// Показатели 0..100. food и water: 100 — сыт/напоен, 0 — смертельно.
class Survival {
public:
    static constexpr float kMax = 100.f;

    float health  = kMax;
    float food    = kMax;
    float water   = kMax;
    float stamina = kMax;
    bool  exhausted = false;
    SurvivalTuning tuning;

    void update(float dt, const SurvivalContext& ctx);

    void eat(float amount);
    void drink(float amount);
    void damage(float amount);
    void reset();

    bool canSprint() const { return !exhausted && stamina > 0.f; }
    bool dead() const { return health <= 0.f; }
};

} // namespace ws
