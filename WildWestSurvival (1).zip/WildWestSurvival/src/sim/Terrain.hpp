#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

#include "sim/Math.hpp"

namespace ws {

// Карта высот: сетка (cells+1)^2 вершин, центр мира в (0, 0).
// Холмы + плоские столовые горы (mesa), к краю карты высота плавно падает до kEdgeLevel.
// Высоту между вершинами считаем по тем же треугольникам, что рисует рендер,
// поэтому игрок никогда не "парит" над землёй и не проваливается.
class Terrain {
public:
    static constexpr float kEdgeLevel = 0.f;
    static constexpr float kEdgeFade  = 50.f;  // ширина затухания у края, метры

    Terrain(int cells, float cellSize, std::uint32_t seed);

    int   cells() const { return cells_; }
    int   vertsPerSide() const { return cells_ + 1; }
    float cellSize() const { return cellSize_; }
    float size() const { return static_cast<float>(cells_) * cellSize_; }
    float halfSize() const { return size() * 0.5f; }

    float vertexCoord(int i) const { return -halfSize() + static_cast<float>(i) * cellSize_; }
    float vertexHeight(int ix, int iz) const { return h_[index(ix, iz)]; }

    // Высота в произвольной точке; за границей карты — значение с ближайшего края.
    float heightAt(float x, float z) const;
    Vec3  normalAt(float x, float z) const;
    // Крутизна: подъём на метр пути (0 — ровно, 1 — 45 градусов).
    float slopeAt(float x, float z) const;

    // Выровнять круг до targetHeight; от innerRadius до outerRadius — плавный переход.
    void flatten(float cx, float cz, float innerRadius, float outerRadius, float targetHeight);
    // Продавить круглую яму глубиной depth (в центре), затухает к outerRadius.
    void carve(float cx, float cz, float innerRadius, float outerRadius, float depth);

private:
    std::size_t index(int ix, int iz) const {
        return static_cast<std::size_t>(iz) * static_cast<std::size_t>(cells_ + 1) +
               static_cast<std::size_t>(ix);
    }

    int           cells_;
    float         cellSize_;
    std::uint32_t seed_;
    std::vector<float> h_;
};

} // namespace ws
