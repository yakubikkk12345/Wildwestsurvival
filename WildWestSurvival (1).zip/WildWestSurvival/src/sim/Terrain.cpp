#include "sim/Terrain.hpp"

#include <algorithm>
#include <cmath>

namespace ws {

namespace {

float hash01(int x, int y, std::uint32_t seed) {
    std::uint32_t h = static_cast<std::uint32_t>(x) * 374761393u +
                      static_cast<std::uint32_t>(y) * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return static_cast<float>(h & 0xFFFFFFu) / 16777215.f;
}

float valueNoise(float x, float y, std::uint32_t seed) {
    const float fx0 = std::floor(x), fy0 = std::floor(y);
    const int xi = static_cast<int>(fx0), yi = static_cast<int>(fy0);
    const float tx = x - fx0, ty = y - fy0;
    const float u = tx * tx * (3.f - 2.f * tx);
    const float v = ty * ty * (3.f - 2.f * ty);
    return lerpf(lerpf(hash01(xi, yi, seed), hash01(xi + 1, yi, seed), u),
                 lerpf(hash01(xi, yi + 1, seed), hash01(xi + 1, yi + 1, seed), u), v);
}

float fbm(float x, float y, std::uint32_t seed, int octaves) {
    float sum = 0.f, amp = 0.5f, norm = 0.f, freq = 1.f;
    for (int i = 0; i < octaves; ++i) {
        sum += amp * valueNoise(x * freq, y * freq, seed + static_cast<std::uint32_t>(i) * 1013u);
        norm += amp;
        amp *= 0.5f;
        freq *= 2.f;
    }
    return sum / norm;
}

float rawHeight(float x, float z, std::uint32_t seed) {
    // Пологие холмы.
    const float hills = (fbm(x * 0.010f, z * 0.010f, seed, 4) - 0.5f) * 2.f * 16.f;
    // Мелкая рябь, чтобы земля не была гладкой.
    const float detail = (fbm(x * 0.070f, z * 0.070f, seed + 77u, 2) - 0.5f) * 2.4f;
    // Столовые горы: там, где крупный шум высок, резко поднимаем плато.
    const float mesaNoise = fbm(x * 0.006f + 31.f, z * 0.006f - 17.f, seed + 5u, 3);
    const float mesa = smoothstep(0.58f, 0.64f, mesaNoise) * 12.f;
    return hills + detail + mesa;
}

} // namespace

Terrain::Terrain(int cells, float cellSize, std::uint32_t seed)
    : cells_(cells),
      cellSize_(cellSize),
      seed_(seed),
      h_(static_cast<std::size_t>(cells + 1) * static_cast<std::size_t>(cells + 1), 0.f) {
    const int n = vertsPerSide();
    const float half = halfSize();
    for (int iz = 0; iz < n; ++iz) {
        for (int ix = 0; ix < n; ++ix) {
            const float x = vertexCoord(ix), z = vertexCoord(iz);
            float h = rawHeight(x, z, seed_);
            const float edge = std::max(std::fabs(x), std::fabs(z));
            h = lerpf(h, kEdgeLevel, smoothstep(half - kEdgeFade, half, edge));
            h_[index(ix, iz)] = h;
        }
    }
}

float Terrain::heightAt(float x, float z) const {
    const float limit = static_cast<float>(cells_) - 0.0001f;
    const float gx = clampf((x + halfSize()) / cellSize_, 0.f, limit);
    const float gz = clampf((z + halfSize()) / cellSize_, 0.f, limit);
    const int ix = static_cast<int>(gx), iz = static_cast<int>(gz);
    const float fx = gx - static_cast<float>(ix), fz = gz - static_cast<float>(iz);

    const float ha = vertexHeight(ix, iz);
    const float hb = vertexHeight(ix + 1, iz);
    const float hc = vertexHeight(ix, iz + 1);
    const float hd = vertexHeight(ix + 1, iz + 1);

    // Диагональ клетки идёт от (ix+1, iz) к (ix, iz+1) — как в меше рендера.
    if (fx + fz <= 1.f) return ha + fx * (hb - ha) + fz * (hc - ha);
    return hd + (1.f - fx) * (hc - hd) + (1.f - fz) * (hb - hd);
}

Vec3 Terrain::normalAt(float x, float z) const {
    const float e = cellSize_;
    const float nx = heightAt(x - e, z) - heightAt(x + e, z);
    const float nz = heightAt(x, z - e) - heightAt(x, z + e);
    const float ny = 2.f * e;
    const float len = std::sqrt(nx * nx + ny * ny + nz * nz);
    return Vec3(nx / len, ny / len, nz / len);
}

float Terrain::slopeAt(float x, float z) const {
    const float e = cellSize_;
    const float dx = (heightAt(x + e, z) - heightAt(x - e, z)) / (2.f * e);
    const float dz = (heightAt(x, z + e) - heightAt(x, z - e)) / (2.f * e);
    return std::sqrt(dx * dx + dz * dz);
}

void Terrain::flatten(float cx, float cz, float innerRadius, float outerRadius, float targetHeight) {
    const int n = vertsPerSide();
    for (int iz = 0; iz < n; ++iz) {
        for (int ix = 0; ix < n; ++ix) {
            const float d = std::hypot(vertexCoord(ix) - cx, vertexCoord(iz) - cz);
            if (d >= outerRadius) continue;
            const float t = 1.f - smoothstep(innerRadius, outerRadius, d);
            float& h = h_[index(ix, iz)];
            h = lerpf(h, targetHeight, t);
        }
    }
}

void Terrain::carve(float cx, float cz, float innerRadius, float outerRadius, float depth) {
    const int n = vertsPerSide();
    for (int iz = 0; iz < n; ++iz) {
        for (int ix = 0; ix < n; ++ix) {
            const float d = std::hypot(vertexCoord(ix) - cx, vertexCoord(iz) - cz);
            if (d >= outerRadius) continue;
            h_[index(ix, iz)] -= depth * (1.f - smoothstep(innerRadius, outerRadius, d));
        }
    }
}

} // namespace ws
