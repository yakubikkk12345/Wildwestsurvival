#pragma once
#include "sim/Math.hpp"

namespace ws {

class Terrain;

// Ввод игрока за кадр. Рендер/окно переводят клавиши и мышь в эту структуру,
// симуляция ничего не знает про клавиатуру.
struct PlayerInput {
    float moveForward = 0.f;  // -1..1 (W/S)
    float moveRight   = 0.f;  // -1..1 (D/A)
    float lookYaw     = 0.f;  // радианы, уже умноженные на чувствительность (вправо > 0)
    float lookPitch   = 0.f;  // радианы (вниз > 0)
    bool  sprint = false;
    bool  jump   = false;
};

struct PlayerFrame {
    bool  moving = false;
    bool  sprinting = false;
    bool  landed = false;
    float impactSpeed = 0.f;  // м/с в момент приземления
};

// Игрок от первого лица: ходьба по рельефу, бег, прыжок, падение.
class Player {
public:
    static constexpr float kEyeHeight   = 1.7f;
    static constexpr float kWalkSpeed   = 4.0f;
    static constexpr float kSprintSpeed = 7.5f;
    static constexpr float kJumpSpeed   = 7.0f;
    static constexpr float kGravity     = 22.f;
    static constexpr float kMaxSlope    = 1.3f;   // круче — не залезть (подъём/пробег)
    static constexpr float kStickDistance = 0.6f; // обрыв глубже — начинаем падать

    // canSprint — разрешает ли бег система выживания (выносливость).
    PlayerFrame update(const PlayerInput& in, const Terrain& terrain, bool canSprint, float dt);

    // Поставить на землю в точке (x, z).
    void teleport(const Terrain& terrain, float x, float z);
    // Поставить в произвольную точку (в том числе в воздухе).
    void setPosition(const Vec3& p);
    // Мягко сдвинуть по горизонтали (выталкивание из препятствий).
    void nudge(float x, float z) { pos_.x = x; pos_.z = z; }

    const Vec3& position() const { return pos_; }   // положение ног
    Vec3 eyePosition() const { return Vec3(pos_.x, pos_.y + kEyeHeight, pos_.z); }
    Vec3 forward() const;                            // куда смотрит камера
    float yaw() const { return yaw_; }
    float pitch() const { return pitch_; }
    bool  grounded() const { return grounded_; }

private:
    bool blocked(const Terrain& terrain, float nx, float nz) const;

    Vec3  pos_;
    float yaw_ = 0.f, pitch_ = 0.f;
    float vx_ = 0.f, vy_ = 0.f, vz_ = 0.f;
    bool  grounded_ = true;
};

} // namespace ws
