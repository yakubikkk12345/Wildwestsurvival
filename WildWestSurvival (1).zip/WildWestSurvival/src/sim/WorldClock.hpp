#pragma once

namespace ws {

// Игровое время. Сутки идут по кругу, от времени зависят свет и температура.
class WorldClock {
public:
    // dayLengthSeconds — сколько реальных секунд длятся игровые сутки.
    explicit WorldClock(float dayLengthSeconds = 720.f, float startHour = 7.f);

    void update(float dt);

    float hour() const { return hour_; }  // 0..24
    int   day()  const { return day_; }   // начиная с 1

    // Угол солнца: 0 — рассвет (6:00), pi/2 — полдень, pi — закат (18:00).
    float sunAngle() const;
    // 0 — глубокая ночь, 1 — полный день (плавный переход на рассвете и закате).
    float daylight() const;
    bool  isNight() const { return daylight() < 0.15f; }
    // Температура воздуха в градусах Цельсия: пустыня жарит днём и стынет ночью.
    float ambientTemperature() const;

private:
    float dayLength_;
    float hour_;
    int   day_ = 1;
};

} // namespace ws
