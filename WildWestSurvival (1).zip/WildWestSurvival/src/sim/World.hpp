#pragma once
#include <cstdint>
#include <vector>

#include "sim/Math.hpp"
#include "sim/Player.hpp"
#include "sim/Survival.hpp"
#include "sim/Terrain.hpp"
#include "sim/WorldClock.hpp"

namespace ws {

enum class PropType : std::uint8_t {
    Cactus,     // колючий: коллизия, при касании ранит, из него можно выжать воду
    Rock,       // камень: коллизия
    DeadTree,   // сухое дерево: коллизия
    Tent,       // палатка в стартовом лагере
    Campfire,   // костёр
    Barrel,     // бочка с водой в лагере
    Crate,      // ящик с припасами
    Count
};

struct Prop {
    PropType type = PropType::Rock;
    Vec3  pos;
    float scale = 1.f;      // общий размер
    float rotation = 0.f;   // поворот вокруг вертикали, радианы
    float radius = 0.5f;    // радиус коллизии в плоскости земли (0 — без коллизии)
    float height = 1.f;     // высота для рендера и подсчёта "выжимания воды"
    bool  harvested = false;
    float respawnIn = 0.f;  // секунды до восстановления (если harvested)
};

struct Oasis {
    Vec3  center;       // y — уровень воды
    float radius = 12.f;       // радиус водной глади
    float shoreRadius = 18.f;  // до сюда рельеф понижен, трава
};

// Что игрок может сделать, глядя на объект. Текст подсказки выбирает HUD (локализация).
struct Interaction {
    enum class Kind : std::uint8_t { None, DrinkOasis, DrinkBarrel, Loot, Cactus };
    Kind kind = Kind::None;
    int  propIndex = -1;
};

struct WorldConfig {
    int           cells = 256;
    float         cellSize = 2.f;       // карта 512 x 512 м
    std::uint32_t seed = 1881;
    int           cactusCount = 260;
    int           rockCount = 140;
    int           deadTreeCount = 60;
    int           oasisCount = 4;
    float         dayLengthSeconds = 720.f;  // 12 минут на сутки
    float         startHour = 7.f;
};

// Весь игровой мир и правила. Не рисует и не слушает клавиатуру:
// Game превращает ввод в PlayerInput и дёргает update(), рендер читает состояние.
class World {
public:
    explicit World(const WorldConfig& cfg = WorldConfig());

    // Один шаг симуляции. interact — нажата ли клавиша действия в этом кадре.
    void update(const PlayerInput& input, bool interact, float dt);
    void respawn();   // после смерти: начать заново в лагере

    const WorldConfig&  config() const { return cfg_; }
    const Terrain&      terrain() const { return terrain_; }
    const WorldClock&   clock() const { return clock_; }
    const Player&       player() const { return player_; }
    const Survival&     survival() const { return survival_; }
    const std::vector<Prop>&  props() const { return props_; }
    const std::vector<Oasis>& oases() const { return oases_; }
    const Interaction&  interaction() const { return interaction_; }

    Vec3 campPosition() const { return camp_; }
    // Находится ли точка в воде оазиса (для рендера и питья).
    bool inOasisWater(float x, float z) const;
    int  deaths() const { return deaths_; }

    // Одноразовые события кадра для звука/эффектов (HUD читает после update).
    struct FrameEvents {
        bool drank = false;
        bool ate = false;
        bool hurt = false;
        bool landed = false;
        bool died = false;
    };
    const FrameEvents& events() const { return events_; }

private:
    void generate();
    void placeProps(std::uint32_t& rng);
    void pushOutOfProps();
    void updateInteraction();
    void doInteract();
    bool freeSpot(float x, float z, float margin) const;
    float distToNearestOasis(float x, float z) const;

    WorldConfig cfg_;
    Terrain     terrain_;
    WorldClock  clock_;
    Player      player_;
    Survival    survival_;
    std::vector<Prop>  props_;
    std::vector<Oasis> oases_;
    Interaction interaction_;
    FrameEvents events_;
    Vec3 camp_;
    int  deaths_ = 0;
    float cactusHurtCooldown_ = 0.f;
};

} // namespace ws
