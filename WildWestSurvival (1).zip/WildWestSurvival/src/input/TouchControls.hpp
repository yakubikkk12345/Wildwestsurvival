#pragma once
#include <vector>

namespace ws {

// Одно касание экрана (координаты в пикселях). Идентификатор не меняется, пока палец на экране.
struct TouchPoint {
    int   id = 0;
    float x = 0.f, y = 0.f;
};

struct TouchCircle {
    float x = 0.f, y = 0.f, r = 0.f;
    bool contains(float px, float py, float slop = 1.f) const {
        const float dx = px - x, dy = py - y, rr = r * slop;
        return dx * dx + dy * dy <= rr * rr;
    }
};

// Раскладка экранных элементов; зависит только от размера экрана.
struct TouchLayout {
    TouchCircle jump;        // кнопка прыжка
    TouchCircle action;      // кнопка действия (пить, резать, обыскивать)
    TouchCircle pause;       // маленькая кнопка паузы в левом верхнем углу
    float stickRadius = 80.f;   // радиус кольца джойстика
    float stickHintX = 0.f, stickHintY = 0.f;  // где рисовать подсказку-кольцо, пока джойстик не активен
    float stickZoneMaxX = 0.f;  // новое касание левее этой границы становится джойстиком
};

// Что экранное управление выдало в этом кадре. Поля-"события" true только в кадре нажатия.
struct TouchOutput {
    float moveForward = 0.f;  // -1..1
    float moveRight = 0.f;    // -1..1
    float lookYaw = 0.f;      // радианы за кадр (вправо > 0), как у мыши
    float lookPitch = 0.f;    // радианы за кадр (вниз > 0)
    bool  sprint = false;     // джойстик отклонён до самого кольца
    bool  jump = false;
    bool  interact = false;
    bool  pause = false;
    bool  tapped = false;     // в этом кадре началось любое новое касание
};

// Плавающий джойстик слева, обзор пальцем справа, кнопки прыжка и действия.
// Не зависит от raylib: на вход список текущих касаний, на выход TouchOutput.
class TouchControls {
public:
    static TouchLayout layoutFor(int screenW, int screenH);

    // Вызывать каждый кадр со списком ВСЕХ касаний, которые сейчас на экране (в том числе пустым).
    void update(const std::vector<TouchPoint>& touches, int screenW, int screenH);
    void reset();

    const TouchOutput& out() const { return out_; }
    const TouchLayout& layout() const { return layout_; }

    // Для отрисовки.
    bool  stickActive() const { return stickActive_; }
    float stickBaseX() const { return baseX_; }
    float stickBaseY() const { return baseY_; }
    float stickKnobX() const { return knobX_; }
    float stickKnobY() const { return knobY_; }
    bool  jumpHeld() const { return jumpHeld_; }
    bool  actionHeld() const { return actionHeld_; }

    float lookSensitivity = 0.0045f;  // радиан на пиксель

private:
    enum class Role { Ignored, Stick, Look, Jump, Action, Pause };
    struct Tracked {
        int   id = 0;
        Role  role = Role::Ignored;
        float lastX = 0.f, lastY = 0.f;
        float baseX = 0.f, baseY = 0.f;  // для джойстика: где коснулись
    };

    TouchOutput out_;
    TouchLayout layout_;
    std::vector<Tracked> tracked_;
    bool  stickActive_ = false, jumpHeld_ = false, actionHeld_ = false;
    float baseX_ = 0.f, baseY_ = 0.f, knobX_ = 0.f, knobY_ = 0.f;
};

} // namespace ws
