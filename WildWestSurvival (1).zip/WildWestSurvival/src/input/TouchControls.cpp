#include "input/TouchControls.hpp"

#include <algorithm>
#include <cmath>

namespace ws {

namespace {
float clampf_(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
constexpr float kButtonSlop = 1.15f;     // попадание чуть мимо кнопки всё равно считается
constexpr float kMoveRange = 0.7f;       // полное движение — при 70% радиуса кольца
constexpr float kDeadZone = 0.12f;
constexpr float kSprintAt = 0.98f;       // бег — когда палец дошёл до кольца
} // namespace

TouchLayout TouchControls::layoutFor(int screenW, int screenH) {
    const float w = static_cast<float>(screenW), h = static_cast<float>(screenH);
    const float unit = std::min(w, h);
    const float R = clampf_(unit * 0.085f, 36.f, 72.f);

    TouchLayout l;
    l.jump = TouchCircle{w - 2.f * R, h - 2.f * R, R};
    l.action = TouchCircle{w - 4.6f * R, h - 1.5f * R, R * 0.9f};
    l.pause = TouchCircle{1.3f * R, 1.3f * R, R * 0.6f};
    l.stickRadius = clampf_(unit * 0.14f, 60.f, 110.f);
    l.stickHintX = l.stickRadius * 1.6f;
    l.stickHintY = h - l.stickRadius * 1.6f;
    l.stickZoneMaxX = w * 0.45f;
    return l;
}

void TouchControls::reset() {
    out_ = TouchOutput();
    tracked_.clear();
    stickActive_ = jumpHeld_ = actionHeld_ = false;
}

void TouchControls::update(const std::vector<TouchPoint>& touches, int screenW, int screenH) {
    out_ = TouchOutput();
    layout_ = layoutFor(screenW, screenH);

    // Убрать пальцы, которые ушли с экрана.
    tracked_.erase(std::remove_if(tracked_.begin(), tracked_.end(),
                                  [&](const Tracked& t) {
                                      return std::none_of(touches.begin(), touches.end(),
                                                          [&](const TouchPoint& p) { return p.id == t.id; });
                                  }),
                   tracked_.end());

    auto hasRole = [&](Role r) {
        return std::any_of(tracked_.begin(), tracked_.end(), [&](const Tracked& t) { return t.role == r; });
    };

    // Новые касания: решаем, чем станет каждый палец.
    for (const TouchPoint& p : touches) {
        const bool known = std::any_of(tracked_.begin(), tracked_.end(), [&](const Tracked& t) { return t.id == p.id; });
        if (known) continue;

        out_.tapped = true;
        Tracked t;
        t.id = p.id;
        t.lastX = t.baseX = p.x;
        t.lastY = t.baseY = p.y;

        if (layout_.pause.contains(p.x, p.y, kButtonSlop)) {
            t.role = Role::Pause;
            out_.pause = true;
        } else if (layout_.jump.contains(p.x, p.y, kButtonSlop)) {
            t.role = Role::Jump;
            out_.jump = true;
        } else if (layout_.action.contains(p.x, p.y, kButtonSlop)) {
            t.role = Role::Action;
            out_.interact = true;
        } else if (p.x < layout_.stickZoneMaxX) {
            t.role = hasRole(Role::Stick) ? Role::Ignored : Role::Stick;
        } else {
            t.role = hasRole(Role::Look) ? Role::Ignored : Role::Look;
        }
        tracked_.push_back(t);
    }

    // Состояние по каждому пальцу.
    stickActive_ = jumpHeld_ = actionHeld_ = false;
    for (Tracked& t : tracked_) {
        const auto it = std::find_if(touches.begin(), touches.end(), [&](const TouchPoint& p) { return p.id == t.id; });
        if (it == touches.end()) continue;  // не бывает после чистки, но на всякий случай
        const float px = it->x, py = it->y;

        switch (t.role) {
            case Role::Stick: {
                const float R = layout_.stickRadius;
                const float dx = px - t.baseX, dy = py - t.baseY;
                const float len = std::sqrt(dx * dx + dy * dy);
                stickActive_ = true;
                baseX_ = t.baseX;
                baseY_ = t.baseY;
                if (len > 1e-3f) {
                    const float ux = dx / len, uy = dy / len;
                    const float shown = std::min(len, R);
                    knobX_ = t.baseX + ux * shown;
                    knobY_ = t.baseY + uy * shown;
                    float mag = std::min(1.f, len / (R * kMoveRange));
                    if (mag < kDeadZone) mag = 0.f;
                    out_.moveRight = ux * mag;
                    out_.moveForward = -uy * mag;  // вверх по экрану — вперёд
                    out_.sprint = len >= R * kSprintAt;
                } else {
                    knobX_ = t.baseX;
                    knobY_ = t.baseY;
                }
                break;
            }
            case Role::Look:
                out_.lookYaw += (px - t.lastX) * lookSensitivity;
                out_.lookPitch += (py - t.lastY) * lookSensitivity;
                break;
            case Role::Jump:
                jumpHeld_ = true;
                break;
            case Role::Action:
                actionHeld_ = true;
                break;
            case Role::Pause:
            case Role::Ignored:
                break;
        }
        t.lastX = px;
        t.lastY = py;
    }
}

} // namespace ws
