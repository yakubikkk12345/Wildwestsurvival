// Минимальные тесты ядра без внешних библиотек.
#include <cmath>
#include <cstdio>

#include "sim/World.hpp"

static int g_failed = 0;
static int g_total = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        ++g_total;                                                           \
        if (!(cond)) {                                                       \
            ++g_failed;                                                      \
            std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);      \
        }                                                                    \
    } while (0)

using namespace ws;

static void testClock() {
    WorldClock c(24.f, 23.f);  // 1 игровой час = 1 секунда
    c.update(2.f);
    CHECK(c.day() == 2);
    CHECK(std::fabs(c.hour() - 1.f) < 0.01f);

    WorldClock noon(100.f, 12.f), midnight(100.f, 0.f);
    CHECK(noon.daylight() > 0.99f);
    CHECK(midnight.daylight() < 0.01f);
    CHECK(midnight.isNight());
    CHECK(noon.ambientTemperature() > midnight.ambientTemperature() + 25.f);
}

static void testSurvival() {
    Survival s;
    SurvivalContext idle;
    idle.ambientTempC = 20.f;
    s.update(10.f, idle);
    CHECK(s.water < 100.f && s.food < 100.f);

    // Жара расходует воду быстрее.
    Survival cool, hot;
    SurvivalContext c, h;
    c.ambientTempC = 20.f;
    h.ambientTempC = 42.f;
    cool.update(10.f, c);
    hot.update(10.f, h);
    CHECK(hot.water < cool.water);

    // Бег истощает выносливость, потом бежать нельзя.
    Survival r;
    SurvivalContext run;
    run.moving = run.sprinting = true;
    for (int i = 0; i < 100; ++i) r.update(0.1f, run);
    CHECK(r.stamina == 0.f);
    CHECK(r.exhausted);
    CHECK(!r.canSprint());
    SurvivalContext rest;
    for (int i = 0; i < 100; ++i) r.update(0.1f, rest);
    CHECK(r.canSprint());

    // Жажда убивает.
    Survival d;
    d.water = 0.f;
    SurvivalContext ctx;
    for (int i = 0; i < 600 && !d.dead(); ++i) d.update(0.1f, ctx);
    CHECK(d.dead());

    Survival e;
    e.water = 10.f;
    e.drink(500.f);
    CHECK(e.water == Survival::kMax);
}

static void testTerrain() {
    Terrain t(64, 2.f, 42);
    Terrain t2(64, 2.f, 42);
    CHECK(t.heightAt(10.f, 20.f) == t2.heightAt(10.f, 20.f));  // детерминизм

    // В вершине высота совпадает с сеткой.
    const float vx = t.vertexCoord(30), vz = t.vertexCoord(40);
    CHECK(std::fabs(t.heightAt(vx, vz) - t.vertexHeight(30, 40)) < 1e-3f);

    // Высота за картой — не падает и конечна.
    CHECK(std::isfinite(t.heightAt(1e6f, -1e6f)));

    // Нормаль единичная и смотрит вверх.
    const Vec3 n = t.normalAt(5.f, 5.f);
    CHECK(std::fabs(std::sqrt(n.x * n.x + n.y * n.y + n.z * n.z) - 1.f) < 1e-3f);
    CHECK(n.y > 0.f);

    // Выравнивание.
    t.flatten(0.f, 0.f, 10.f, 20.f, 5.f);
    CHECK(std::fabs(t.heightAt(0.f, 0.f) - 5.f) < 1e-3f);
    CHECK(std::fabs(t.heightAt(3.f, -4.f) - 5.f) < 1e-3f);
}

static PlayerInput forwardInput() {
    PlayerInput in;
    in.moveForward = 1.f;
    return in;
}

static void testPlayer() {
    Terrain t(64, 2.f, 7);
    Player p;
    p.teleport(t, 0.f, 0.f);
    CHECK(std::fabs(p.position().y - t.heightAt(0.f, 0.f)) < 1e-3f);

    // Идёт вперёд (yaw = 0 → вдоль +Z).
    const float z0 = p.position().z;
    for (int i = 0; i < 60; ++i) p.update(forwardInput(), t, false, 1.f / 60.f);
    CHECK(p.position().z > z0 + 2.f);

    // Бег быстрее ходьбы.
    Player w, s;
    w.teleport(t, 0.f, -20.f);
    s.teleport(t, 0.f, -20.f);
    PlayerInput run = forwardInput();
    run.sprint = true;
    for (int i = 0; i < 60; ++i) {
        w.update(forwardInput(), t, true, 1.f / 60.f);
        s.update(run, t, true, 1.f / 60.f);
    }
    CHECK(s.position().z > w.position().z);

    // Без выносливости бег не работает.
    Player n, m;
    n.teleport(t, 0.f, -20.f);
    m.teleport(t, 0.f, -20.f);
    for (int i = 0; i < 60; ++i) {
        n.update(run, t, false, 1.f / 60.f);
        m.update(forwardInput(), t, false, 1.f / 60.f);
    }
    CHECK(std::fabs(n.position().z - m.position().z) < 1e-3f);

    // Прыжок: взлетает и приземляется.
    Player j;
    j.teleport(t, 0.f, 0.f);
    PlayerInput jump;
    jump.jump = true;
    j.update(jump, t, false, 1.f / 60.f);
    CHECK(!j.grounded());
    bool landed = false;
    for (int i = 0; i < 240 && !landed; ++i)
        landed = j.update(PlayerInput(), t, false, 1.f / 60.f).landed;
    CHECK(landed);
    CHECK(j.grounded());

    // Не выходит за карту.
    Player e;
    e.teleport(t, 0.f, 0.f);
    for (int i = 0; i < 60 * 60; ++i) e.update(forwardInput(), t, true, 1.f / 60.f);
    CHECK(e.position().z <= t.halfSize());
}

static void testWorld() {
    WorldConfig cfg;
    cfg.cells = 128;
    cfg.cactusCount = 60;
    cfg.rockCount = 30;
    cfg.deadTreeCount = 10;
    cfg.oasisCount = 2;
    World w(cfg);
    World w2(cfg);

    CHECK(w.props().size() == w2.props().size());  // детерминизм
    CHECK(!w.oases().empty());
    CHECK(w.player().grounded());

    // Никто не стоит внутри препятствия на старте.
    const Vec3 sp = w.player().position();
    for (const Prop& pr : w.props())
        if (pr.radius > 0.f) CHECK(std::hypot(sp.x - pr.pos.x, sp.z - pr.pos.z) > pr.radius);

    // Оазисы: вода есть, и стоя у воды можно пить.
    const Oasis& o = w.oases().front();
    CHECK(w.inOasisWater(o.center.x, o.center.z));
    CHECK(!w.inOasisWater(o.center.x + o.radius + 5.f, o.center.z));
    // Дно под водой внутри, берег выше воды снаружи.
    CHECK(w.terrain().heightAt(o.center.x + o.radius * 0.8f, o.center.z) < o.center.y);
    CHECK(w.terrain().heightAt(o.center.x + o.radius + 3.f, o.center.z) > o.center.y);

    // Мир живёт: время идёт, вода убывает.
    const float hour0 = w.clock().hour();
    const float water0 = w.survival().water;
    for (int i = 0; i < 600; ++i) w.update(PlayerInput(), false, 1.f / 60.f);
    CHECK(w.clock().hour() != hour0);
    CHECK(w.survival().water < water0);

    // Игрок, оставленный без воды, умирает, а respawn оживляет.
    World d(cfg);
    for (int i = 0; i < 60 * 60 * 30 && !d.survival().dead(); ++i)
        d.update(PlayerInput(), false, 0.1f);
    CHECK(d.survival().dead());
    CHECK(d.deaths() == 1);
    d.respawn();
    CHECK(!d.survival().dead());
    CHECK(d.survival().water == Survival::kMax);

    // Ящик в лагере: берём припасы один раз.
    World l(cfg);
    int crate = -1;
    for (std::size_t i = 0; i < l.props().size(); ++i)
        if (l.props()[i].type == PropType::Crate) { crate = static_cast<int>(i); break; }
    CHECK(crate >= 0);
}

int main() {
    testClock();
    testSurvival();
    testTerrain();
    testPlayer();
    testWorld();
    std::printf("%d/%d проверок пройдено\n", g_total - g_failed, g_total);
    return g_failed == 0 ? 0 : 1;
}
