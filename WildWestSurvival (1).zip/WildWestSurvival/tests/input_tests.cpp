// Тесты сенсорного управления (без raylib).
#include <cmath>
#include <cstdio>
#include <vector>

#include "input/TouchControls.hpp"

static int g_failed = 0;
static int g_total = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        ++g_total;                                                           \
        if (!(cond)) {                                                       \
            ++g_failed;                                                      \
            std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);      \
        }                                                                    \
    } while (0)

using namespace ws;
using Touches = std::vector<TouchPoint>;

static constexpr int W = 1280, H = 720;

static void testLayout() {
    for (const auto& size : {std::pair<int, int>{1280, 720}, {844, 390}, {2400, 1080}, {640, 360}}) {
        const TouchLayout l = TouchControls::layoutFor(size.first, size.second);
        // Кнопки не пересекаются друг с другом и лежат на правой стороне, вне зоны джойстика.
        const float d = std::hypot(l.jump.x - l.action.x, l.jump.y - l.action.y);
        CHECK(d > (l.jump.r + l.action.r) * 1.15f);
        CHECK(l.action.x - l.action.r * 1.15f > l.stickZoneMaxX);
        CHECK(l.jump.x + l.jump.r <= static_cast<float>(size.first));
        CHECK(l.jump.y + l.jump.r <= static_cast<float>(size.second));
    }
}

static void testStick() {
    TouchControls tc;
    const TouchLayout l = TouchControls::layoutFor(W, H);

    // Палец вверх от точки касания — вперёд.
    tc.update({{1, 200.f, 500.f}}, W, H);
    CHECK(tc.stickActive());
    CHECK(tc.out().moveForward == 0.f && tc.out().moveRight == 0.f);  // сразу после касания стоим
    tc.update({{1, 200.f, 500.f - l.stickRadius * 0.7f}}, W, H);
    CHECK(tc.out().moveForward > 0.95f);
    CHECK(std::fabs(tc.out().moveRight) < 0.01f);
    CHECK(!tc.out().sprint);  // 70% кольца — идём, но не бежим

    // Вправо и назад.
    tc.update({{1, 200.f + l.stickRadius * 0.7f, 500.f}}, W, H);
    CHECK(tc.out().moveRight > 0.95f);
    tc.update({{1, 200.f, 500.f + l.stickRadius * 0.7f}}, W, H);
    CHECK(tc.out().moveForward < -0.95f);

    // До самого кольца и дальше — бег; ручка не уходит за кольцо.
    tc.update({{1, 200.f, 500.f - l.stickRadius * 1.5f}}, W, H);
    CHECK(tc.out().sprint);
    CHECK(tc.out().moveForward <= 1.f + 1e-4f);
    CHECK(std::fabs(tc.stickKnobY() - (500.f - l.stickRadius)) < 0.01f);

    // Мёртвая зона.
    tc.update({{1, 203.f, 500.f}}, W, H);
    CHECK(tc.out().moveRight == 0.f);

    // Диагональ не даёт скорость больше 1.
    tc.update({{1, 200.f + 200.f, 500.f - 200.f}}, W, H);
    CHECK(std::hypot(tc.out().moveForward, tc.out().moveRight) <= 1.0001f);

    // Отпустили палец — всё обнулилось.
    tc.update({}, W, H);
    CHECK(!tc.stickActive());
    CHECK(tc.out().moveForward == 0.f && tc.out().moveRight == 0.f && !tc.out().sprint);
}

static void testLook() {
    TouchControls tc;
    tc.update({{7, 900.f, 300.f}}, W, H);
    CHECK(tc.out().lookYaw == 0.f);  // первый кадр без рывка
    tc.update({{7, 940.f, 300.f}}, W, H);
    CHECK(tc.out().lookYaw > 0.f);
    CHECK(std::fabs(tc.out().lookYaw - 40.f * tc.lookSensitivity) < 1e-5f);
    tc.update({{7, 940.f, 330.f}}, W, H);
    CHECK(tc.out().lookPitch > 0.f && tc.out().lookYaw == 0.f);
    tc.update({{7, 940.f, 330.f}}, W, H);  // палец неподвижен — обзор не дрейфует
    CHECK(tc.out().lookYaw == 0.f && tc.out().lookPitch == 0.f);
}

static void testButtons() {
    TouchControls tc;
    const TouchLayout l = TouchControls::layoutFor(W, H);

    // Прыжок: событие только в кадре нажатия, потом "зажата".
    tc.update({{1, l.jump.x, l.jump.y}}, W, H);
    CHECK(tc.out().jump);
    CHECK(!tc.out().interact);
    CHECK(tc.jumpHeld());
    tc.update({{1, l.jump.x, l.jump.y}}, W, H);
    CHECK(!tc.out().jump);
    CHECK(tc.jumpHeld());
    tc.update({}, W, H);
    CHECK(!tc.jumpHeld());

    // Действие.
    tc.update({{2, l.action.x, l.action.y}}, W, H);
    CHECK(tc.out().interact && !tc.out().jump);
    CHECK(tc.actionHeld());
    tc.update({}, W, H);

    // Пауза.
    tc.update({{3, l.pause.x, l.pause.y}}, W, H);
    CHECK(tc.out().pause);
    CHECK(!tc.stickActive());  // нажатие на паузу не становится джойстиком
    tc.update({}, W, H);

    // Палец, начавший движение в зоне обзора и заехавший на кнопку, кнопку не нажимает.
    tc.update({{4, 900.f, 300.f}}, W, H);
    tc.update({{4, l.jump.x, l.jump.y}}, W, H);
    CHECK(!tc.out().jump);
}

static void testMultiTouch() {
    TouchControls tc;
    const TouchLayout l = TouchControls::layoutFor(W, H);

    // Одновременно: джойстик, обзор и прыжок.
    tc.update({{1, 200.f, 500.f}, {2, 900.f, 300.f}}, W, H);
    CHECK(tc.stickActive());
    tc.update({{1, 200.f, 500.f - 80.f}, {2, 930.f, 300.f}, {3, l.jump.x, l.jump.y}}, W, H);
    CHECK(tc.out().moveForward > 0.f);
    CHECK(tc.out().lookYaw > 0.f);
    CHECK(tc.out().jump);

    // Третий палец в зоне обзора, пока обзор уже занят, игнорируется.
    tc.update({{1, 200.f, 420.f}, {2, 930.f, 300.f}, {3, l.jump.x, l.jump.y}, {4, 800.f, 200.f}}, W, H);
    tc.update({{1, 200.f, 420.f}, {2, 930.f, 300.f}, {3, l.jump.x, l.jump.y}, {4, 900.f, 200.f}}, W, H);
    CHECK(tc.out().lookYaw == 0.f);

    // Отпустили джойстик, обзор продолжает работать.
    tc.update({{2, 960.f, 300.f}}, W, H);
    CHECK(!tc.stickActive());
    CHECK(tc.out().moveForward == 0.f);
    CHECK(tc.out().lookYaw > 0.f);
}

static void testTapAndReset() {
    TouchControls tc;
    tc.update({}, W, H);
    CHECK(!tc.out().tapped);
    tc.update({{1, 640.f, 360.f}}, W, H);
    CHECK(tc.out().tapped);
    tc.update({{1, 640.f, 360.f}}, W, H);
    CHECK(!tc.out().tapped);  // удержание — не новый тап

    tc.reset();
    CHECK(!tc.stickActive() && !tc.jumpHeld());
    tc.update({{1, 640.f, 360.f}}, W, H);
    CHECK(tc.out().tapped);   // после reset тот же id снова считается новым касанием
}

int main() {
    testLayout();
    testStick();
    testLook();
    testButtons();
    testMultiTouch();
    testTapAndReset();
    std::printf("%d/%d проверок пройдено\n", g_total - g_failed, g_total);
    return g_failed == 0 ? 0 : 1;
}
